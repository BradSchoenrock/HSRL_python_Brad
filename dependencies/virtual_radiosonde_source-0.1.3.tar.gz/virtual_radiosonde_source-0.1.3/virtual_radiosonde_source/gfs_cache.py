#!/usr/bin/env python
# encoding: utf-8
"""
gfs_cache.py
$Id: gfs_cache.py 374 2013-02-15 20:25:57Z bmurray $

Purpose: provide access to GFS cache, prioritizing by best available (least predictive) data for a given timestep.

Derived from code from Geoff Cureton, Denny Hackel, Kathy Strabala.


Created by rayg@ssec.wisc.edu
Copyright (c) 2012 University of Wisconsin SSEC. All rights reserved.
"""
import os, sys
import logging

from datetime import datetime, timedelta, date
import ftplib
from urlparse import urlsplit

LOG = logging.getLogger(__name__)

DEFAULT_BASE = '/data'

# hh is when the GFS was run; ooo is how far out it predicts
PRO_FMT = 'edr/gfs/%(yyyy)04d/%(jjj)03d/gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2' 
BACKFILL_FMT = 'tmp/geoarc/edr/gfs/%(yyyy)04d/%(jjj)03d/gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2' 
DEFAULT_FORMAT = PRO_FMT 



def snap_3h(dt, round_up=False):
    "snap time to 3h intervals, rounding down by default"
    if dt.hour%3==0 and dt.minute==0 and dt.second==0 and dt.microsecond==0: 
        return dt
    if round_up: 
        dt = dt + timedelta(hours=3)
    return dt.replace(hour=dt.hour-(dt.hour%3), minute=0, second=0, microsecond=0)

def floor_1h(dt):
    return dt.replace(minute=0, second=0, microsecond=0)

def _first_day_of_month(dt, months_offset = 0):
    """return the date object of the first day of the month containing dt
    optional months_offset is +- value for months to add
    """
    when = date(dt.year, dt.month, 15)
    while months_offset > 0: 
        when += timedelta(days=32)
        when = date(when.year, when.month, 15)
        months_offset -= 1
    while months_offset < 0: 
        when -= timedelta(days=32)
        when = date(when.year, when.month, 15)
        months_offset += 1
    when = date(when.year, when.month, 1)    
    return when

def convert2regex(regex):
    """
    Convert python format string to re regex
    """

    import re
    #Get formatted string lengths
    lens = dict(re.findall('%\((?P<key>[a-z]*)\)(?P<type>[0-9]{2})[d,f]',regex))
    #Make a regex pattern dictionary
    reFMT_dict = { key:'(?P<%s>[0-9]{%01d})' % (key,int(lens[key])) for key in lens}
    #Place regex patterns in old python format string
    reFMT = re.sub('(?<=\)[0-9]{2})([d,f])','s',regex) % reFMT_dict
    return reFMT

def strp_datetime(filename,FMT):
    """
    Take filename and format and return datetime
    """
    import re
    filename = os.path.basename(filename)
    FMT = os.path.basename(FMT)

    #Match all time vars into dictionary
    reFMT = convert2regex(FMT)
    match = re.match(reFMT,filename).groupdict()
    regex2datetime = {
         'yyyy':'%Y',
         'yy':'%y',
         'jjj':'%j',
         'mm':'%m',
         'dd':'%d',
         'hh':'%H',
         }

    offset = timedelta(0)
    if 'ooo' in match:
        offset = timedelta(hours=int(match.pop('ooo')))

    match = {regex2datetime [key]:match[key] for key in match}
    strpFmtString = ''.join(match.keys())
    dtstring = ''.join(match.values())
    dt = datetime.strptime(dtstring,strpFmtString)
    dt += offset
    return dt

def strp_datetime_gdas(filename):
    return strp_datetime(filename,URL_FMT_SSEC_GDAS)
    
def strp_datetime_gfs(filename):
    return strp_datetime(filename,PRO_FMT)


def _datetime_dict(dt, **moar):
    """
    generate a dictionary of fields useful for generating URIs procedurally
    yyyy: 4-digit year
    yy: 2-digit year 
    jjj: julian day 
    mm: month of year (1-12)
    dd: day of month (1-31)
    hh: hour of the day that the forecast ran
    jms: julian day of first day of the month
    jme: julian day of last day of the month
    This is typically augmented with ooo, the hours' predictive that the forecast operated at
    """
    d_mon_start = _first_day_of_month(dt, +0)
    d_mon_end = _first_day_of_month(dt, +1) + timedelta(days=-1)
    zult = dict(yyyy = dt.year,
                yy = dt.year % 100,
                jjj = int(dt.strftime('%j')),
                jms = int(d_mon_start.strftime('%j')),
                jme = int(d_mon_end.strftime('%j')),
                mm = dt.month,
                dd = dt.day,
                hh = dt.hour)
    zult.update(moar)
    return zult


# TODO: change PRO_BASE back to DEFAULT_BASE
def dread0_cache(relpath, base=DEFAULT_BASE):
    """
    check LDM cache on dreadnaught, assuming it's localhost
    FUTURE: use rsync to fetch from dreadnaught
    """
    full_path = os.path.join(base, relpath)
    LOG.debug("Checking cache for %s",full_path)
    if os.path.isfile(full_path):
        return full_path
    return None

def gfs_guess_source():
    """
    make a good guess on what the best source and format pattern are to use for this machine
    returns (format, cache-func)
    """

    # FIXME: find better way to differentiate between these two cases
    if True:#not os.environ.get('HOSTNAME', '-unknown-').startswith('dreadnaught'):
        cache_dir = os.environ.get('GFS_CACHE_DIR', os.environ.get('TMPDIR', '/tmp'))
        return URL_FMT_DREAD0_RSYNC, lambda url: cache_dread0_rsync(cache_dir, url)        
    else:
        LOG.debug('Guessing source: %s,%s',DEFAULT_FORMAT,dread0_cache)
        return DEFAULT_FORMAT, dread0_cache

def cache_url(cache_dir, url):
    from urllib2 import urlopen
    basename = os.path.split(url)[-1]
    cache_path = os.path.join(cache_dir, basename)
    if os.path.exists(cache_path): 
        return cache_path
    try:
        print >>sys.stderr, "trying %s" % url
        uf = urlopen(url)
        fp = open(cache_path, 'wb')
        fp.write(uf.read())
        fp.close()
        return cache_path
    except:
        return None

class cache_url_ftp:

    def __init__(self,cache_dir):
        self.cache_dir = cache_dir

    def __call__(self,url):
        try:
            if self.ftp.nlst(urlsplit(url).path):
                return cache_url(self.cache_dir,url)
        except ftplib.error_temp as err:
            LOG.info(err)

    def __enter__(self):
        url = urlsplit(URL_FMT_SSEC_GFS)
        self.ftp = ftplib.FTP(url.hostname)
        self.ftp.login()

    def __exit__(self,*args):
        self.ftp.close()

def search(when,cache,format,timesteps=None):
    # hours to trade into prediction offset
    # e.g. for 12:00:00 we prefer 12_000 but are ok with 
    dh = 0 
    # adjustment since we're on 3-hour boundaries, but only have observations at 6-hour intervals
    adjust = when.hour % 6
    timesteps = timestep_gen() if timesteps is None else timesteps
    for dh in timesteps:
        ooo = dh + adjust
        magic = 81 if ooo==0 else 96   # used for geoarc archive
        url = format % _datetime_dict(when - timedelta(hours = ooo), ooo = ooo, magic = magic)
        path = cache(url)
        if path:
            LOG.debug('found %s for %s' % (path, when))
            yield path

def timestep_gen():
    "generate timesteps for GFS runs"
    return range(0,24,3)

def gfs_cache_list(when,format=None,cache=None,timesteps=None):
    """
    List all gfs files that represent a particular time
    """
    when = snap_3h(when, round_up=False)
    LOG.debug(str(when))
    
    if format is None or cache is None:
        LOG.debug('cache is None or format is None')
        format, cache = gfs_guess_source()

    return list(search(when,cache,format,timesteps=timesteps))

def gfs_cache(when, format=None, cache=None, timesteps=None):
    """search the repository for a UTC time on a 3-hour boundary.
    returns the least predictive file available
    Note that 0,6,12,18 analyses are best
    """
    when = snap_3h(when, round_up=False)
    LOG.debug(str(when))
    
    if format is None or cache is None:
        LOG.debug('cache is None or format is None')
        format, cache = gfs_guess_source()

    try:
        return search(when,cache,format,timesteps=timesteps).next()
    except StopIteration:
        LOG.warning('no GFS data found for %s' % when)
        return None

# hour set : (hh, hours_delta)
_GDAS_TIMESTEP = {(0,1,2): (0,0),
                  (3,4,5,6,7,8): (6,0),
                  (9,10,11,12,13,14): (12,0),
                  (15,16,17,18,19,20): (18,0),
                  (21,22,23): (0,24) }

GDAS_TIMESTEP = dict()
for set_hh, adj in _GDAS_TIMESTEP.items():
    GDAS_TIMESTEP.update(dict((hh,adj) for hh in set_hh))

def gdas_cache(when, format=None, cache=None):
    """search the repository for the nearest-time GDAS 6-hour assimilation
    """
    LOG.debug(str(when))

    when = floor_1h(when)
    hh, dh = GDAS_TIMESTEP[when.hour]

    if format is None or cache is None:
        format, cache = gfs_guess_source()

    base = when.replace(hour=0) + timedelta(hours=dh)
    target = base.replace(hour=hh)

    url = format % _datetime_dict(target, ooo = 0)
    path = cache(url)
    if path:
        LOG.debug('found %s for %s' % (path, when))
        return path
    LOG.info('no GDAS data found for %s' % when)
    return None


# /pub/eosdb/ancillary/2012_09_19_263/forecast/gfs.t12.120919.pgrbf06
# FUTURE: handle GDAS vs GFS
# GFS grib1 repo on ftp
#URL_FMT_SSEC_GFS = 'ftp://ftp.ssec.wisc.edu/pub/eosdb/ancillary/%(yyyy)04d_%(mm)02d_%(dd)02d_%(jjj)02d/forecast/gfs.t%(hh)02d.%(yy)02d%(mm)02d%(dd)02d.pgrbf%(ooo)02d'
URL_FMT_SSEC_GFS = 'ftp://ftp.ssec.wisc.edu/pub/eosdb/ancillary/%(yyyy)04d_%(mm)02d_%(dd)02d_%(jjj)02d/forecast/gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2'

# GDA grib1 repo on ftp, only timestep 0 available for GDAS
URL_FMT_SSEC_GDAS = 'ftp://ftp.ssec.wisc.edu/pub/eosdb/ancillary/%(yyyy)04d_%(mm)02d_%(dd)02d_%(jjj)02d/gdas1.PGrbF%(ooo)02d.%(yy)02d%(mm)02d%(dd)02d.%(hh)02dz'

   
def gfs_ftp_ssec(when, cache_dir='.'):
    cache = lambda url: cache_url(cache_dir, url)
    return gfs_cache(when, URL_FMT_SSEC_GFS, cache)

def gdas_ftp_ssec(when, cache_dir='.'):
    cache = lambda url: cache_url(cache_dir, url)
    return gdas_cache(when, URL_FMT_SSEC_GDAS, cache)

def gdas_gfs_ftp_ssec(when, cache_dir='.'):
    "use GDAS if available (typically data >24h), else gfs"
    zult = gdas_ftp_ssec(when, cache_dir)
    return zult if zult is not None else gfs_ftp_ssec(when, cache_dir)

def check_gdas_ftp_ssec(whens):
    import ftplib
    from urlparse import urlsplit

    cache = lambda url: url
    url = urlsplit(URL_FMT_SSEC_GDAS)
    ftp = ftplib.FTP(url.hostname)
    ftp.login()
    for when in whens:
        query = gdas_cache(when,URL_FMT_SSEC_GDAS,cache)
        try:
            confirm = ftp.nlst(urlsplit(query).path)
            if confirm:
                yield query, when
            else:
                yield None
        except:
            yield None
    ftp.close()

# local repository on dreadnaught (redundant? see line 27)
# DEFAULT_FORMAT = 'edr/gfs/%(yyyy)04d/%(jjj)03d/gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2' 

# remote repo on dreadnaught
URL_FMT_DREAD0_RSYNC = 'rsync://dreadnaught.ssec.wisc.edu/data/edr/gfs/%(yyyy)04d/%(jjj)03d/gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2'

URL_FMT_DREAD0_SCP = '%(tunnel)s:/data/edr/gfs/%(yyyy)04d/%(jjj)03d/gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2'

def cache_dread0_rsync(cache_dir, url):
    """
    cache rsync urls from dreadnaught.ssec.wisc.edu
    """
    from subprocess import call
    from subprocess import PIPE
    filename = os.path.split(url)[-1]
    cache_path = os.path.join(cache_dir, filename)
    LOG.debug('seeing if cache contains %s' % cache_path)
    if os.path.exists(cache_path): 
        return cache_path
    LOG.info('looking for %s' % url)
    rc = call(['rsync', '-uaq', url, cache_path],stderr=PIPE)
    if (rc==0) and os.path.exists(cache_path):
        LOG.debug('downloaded %s to %s successfully' % (url, cache_path))
        return cache_path
    return None

def cache_dread0_scp(cache_dir, url, port):
    """
    cache scp urls from dreadnaught.ssec.wisc.edu
    """
    from subprocess import call
    filename = os.path.split(url)[-1]
    cache_path = os.path.join(cache_dir, filename)
    LOG.debug('seeing if cache contains %s' % cache_path)
    if os.path.exists(cache_path): 
        return cache_path
    LOG.info('looking for %s' % url)
    rc = call(['scp', '-P', str(port), url, cache_path])
    if (rc==0) and os.path.exists(cache_path):
        LOG.debug('downloaded %s to %s successfully' % (url, cache_path))
        return cache_path
    return None

def gfs_rsync_dread0(when, cache_dir='.'):
    # cache = lambda url: cache_dread0_rsync(cache_dir, url)
    return gfs_cache(when) #, URL_FMT_DREAD0_RSYNC, cache)


URL_FMT_GEOARC_HTTP = ''.join([ "http://geoarc04.ssec.wisc.edu:8080/thredds/fileServer/ssec_archive_grid/",
                                "%(yyyy)d/%(yyyy)d_%(mm)02d_%(jms)03d-%(jme)03d/%(mm)02d_%(dd)02d_%(jjj)03d/other/",
                                "GFS_%(magic)03d_%(yyyy)d_%(jjj)03d_%(mm)02d_%(dd)02d_RH%(hh)02d00_FH%(ooo)04d_000_0p5000x0p5000_XXX_XXXX_XXX.grib2"
                                ])



def geoarc_urls(start, end, url_fmt_in=None, path_fmt_out=None):
    """
    generate source-url, dest-path pairs for a time range 
    this is used to back-fill the dreadnaught cache from geoarc @ SSEC
    """
    path_fmt_out = os.path.join('/data/tmp/geoarc', DEFAULT_FORMAT) if path_fmt_out is None else path_fmt_out
    url_fmt_in = URL_FMT_GEOARC_HTTP if url_fmt_in is None else url_fmt_in
    when = start.replace(hour=start.hour-(start.hour%6), minute=0, second=0, microsecond=0)    
    timesteps = [0, 3] # we only need the FH0 and FH3 for retrospective full coverage, with RH0,6,12,18
    while when < end:
        for dh in timesteps:
            # include magic as "magic number" which differs for analysis outputs at FH0000
            nfo = _datetime_dict(when, ooo = dh, magic = 81 if dh==0 else 96)
            url = url_fmt_in % nfo
            dst = path_fmt_out % nfo
            yield url, dst
        when += timedelta(hours = 6)

def geoarc_backfill(start, end):
    """
    build a backfill script for a time range
    """
    for url, path in geoarc_urls(start, end):
        dstdir = os.path.split(path)[0]
        print 'test -d %s || mkdir -p %s' % (dstdir, dstdir)
        print 'test -f %s || curl -f %s -o %s' % (path, url, path)
        print 'sleep 1'
    
def geoarc_backfill_main(*args):
    assert(len(args)>0)
    yyyymmdd = lambda s: datetime.strptime(s, '%Y%m%d')
    start = yyyymmdd(args[0])
    end = yyyymmdd(args[1]) if (len(args)>1) else (start + timedelta(days=1))
    geoarc_backfill(start, end)

def input_time(s, fmt='%Y%j %H%M'):
    when = datetime.strptime(s,fmt)
    return when

def main():
    # FUTURE: this is really crude
    if ("GEOARC_BACKFILL" in os.environ) and len(sys.argv)>0:
        geoarc_backfill_main(*sys.argv[1:])        
        return 0
    if len(sys.argv)==1:
        print "usage: gfs_cache.py yyyymmddThh destination_dir" 
        print "optional GFS_CACHE_DIR environment variable"
        print "optional GFS_SOURCE=dread0 environment variable"
        print "example: gfs_cache.py 2012263 1715" 
        print "alternate mode: GEOARC_BACKFILL=yes gfs_cache.py 20121101 20121201    # generate cache back-fill shell script"
        sys.exit(1)
    when = input_time(' '.join(sys.argv[1:]))
    if os.environ.get('GFS_SOURCE', None) == 'dread0':
        print gfs_rsync_dread0(when, os.environ.get('GFS_CACHE_DIR', '.'))
    else:
        print gdas_gfs_ftp_ssec(when, os.environ.get('GFS_CACHE_DIR', '.'))
    return 0

if __name__=='__main__':
    logging.basicConfig(level=logging.DEBUG)
    sys.exit(main())
