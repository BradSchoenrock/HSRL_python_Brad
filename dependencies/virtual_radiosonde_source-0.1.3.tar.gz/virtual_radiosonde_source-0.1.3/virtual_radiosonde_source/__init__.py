"""
Virtual Radiosonde Source
=========================

Provides:
    1. A generated stream of NWP data frames formatted as radiosondes.
       Each frame can have a unique time and location.
    2. A utility to save radiosonde data frames as netCDF files that resemble the actual radiosonde CDFs.


Avaliable modules
-----------------
    vrsNarrator
        A DPL-like narrator that can provide a series of radiosonde frames for each
        time and location specified in an iterable.

    vrs
        A different front-end for vrsNarrator so that it does not take an iterable,
        only the mapping. All iteration is done outside the package.

    vrsWeaver
        A netCDF3 writer. Uses data frames from vrsNarrator or vrs to compile a
        netcdf file similar to those of actual radiosondes.  
    
    artist
        Converts frame stream to imagery.

    cdfNarrator
        Can search a directory for netcdfs output by the weaver and replay the original.

"""

    
