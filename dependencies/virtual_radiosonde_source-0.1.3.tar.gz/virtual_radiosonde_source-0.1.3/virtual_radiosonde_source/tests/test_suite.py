from virtual_radiosonde_source import vrsNarrator
from virtual_radiosonde_source import vrs
from virtual_radiosonde_source import vrsWeaver
from virtual_radiosonde_source import cdfNarrator
from virtual_radiosonde_source import artist
import numpy
import logging
import time
import sys
import os
import unittest

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)

DOWNLOAD_METHOD='ftp'
DEFAULT_BASE = vrsNarrator.DEFAULT_BASE

def _run_interface(**kwargs):
    """
    Test info:
        Online
        No caching
    """
    LOGGER.info('\n\nTESTING INTERFACE\n-----------------')
    results = vrs._test_ray(download_method=DOWNLOAD_METHOD,**kwargs)
    return results

def _run_cache_fill(**kwargs):
    """
    Test info:
        Online
        Caching
        Narrated
    """
    LOGGER.info('\n\nTESTING CACHE FILLING\n------------------')
    results = vrsNarrator._test_cache_fill(download_method=DOWNLOAD_METHOD,**kwargs)
    return results

def _run_cache(**kwargs):
    """
    Test info:
        Offline
        Caching
        Narrated
    """
    LOGGER.info('\n\nTESTING CACHE OFFLINE\n---------------------')
    results = vrsNarrator._test_cache(**kwargs)
    return results

def _run_channels(**kwargs):
    """
    Test info:
        Offline
        No internal caching
        Narrated
    """
    newChannel = 'Vertical velocity'
    LOGGER.info('\n\nTESTING CUSTOM CHANNELS\n-----------------------')
    LOGGER.info('Using '+newChannel+' and default channels....')
    newChannels = vrsNarrator.DEFAULT_CHANNELS.union(set([newChannel]))
    results = vrsNarrator._test_cache(channels=newChannels,**kwargs)
    return results

def _run_test_levels(**kwargs):
    """
    Test info:
        Offline
        No internal caching
        Narrated
    """
    LOGGER.info('\n\nTESTING CUSTOM LEVELS\n---------------------')
    LOGGER.info('Using 3 levels')
    newLevels = [1000, 500, 100]
    LOGGER.info('New levels = %s',str(newLevels))
    results = vrsNarrator._test_cache(levels=newLevels,**kwargs)
    return results

class OnlineTests(unittest.TestCase):
    
    def test_interface(self):
        results = _run_interface()
        self.assertEqual(len(results), vrs.NSTEPS)

    def test_cache_fill(self):
        results = _run_cache_fill()
        self.assertGreater(len(results), 0)

class OfflineTests(unittest.TestCase):

    def setUp(self):
        try:
            LOGGER.info('making directory %s',DEFAULT_BASE)
            os.mkdir(vrsNarrator.DEFAULT_BASE)
        except OSError as e:
            pass
        span = vrs.NSTEPS
        times = map(lambda time: time['datetime'],vrsNarrator._test_times(span=span))
        cache_dir = DEFAULT_BASE
        try:
            vrsNarrator._check_file_cache(times,cache_dir)
        except ValueError:
            LOGGER.info('Need to fill cache, filling cache...')
            ob = vrsNarrator.VirtualRadiosondeNarrator(cache=DEFAULT_BASE,download=True,
                download_method=DOWNLOAD_METHOD)
            with ob.cache:
                ob.fill_cache(times)

    def test_surface(self):
        results = _run_interface(download=False,channels=vrsNarrator.DEFAULT_CHANNELS.union(['Surface Temperature']))
        self.assertEqual(len(results),vrs.NSTEPS)
        self.assertIn('Surface Temperature', results[0].keys())


    def test_interface(self):
        results = _run_interface(download=False)
        self.assertEqual(len(results), vrs.NSTEPS)

    def test_cache(self):
        results = _run_cache(download=False)
        self.assertGreater(len(results), 0)
    
    def test_channels(self):
        results = _run_channels(download=False)
        self.assertIsNotNone(results[0]['Vertical velocity'])

    def test_levels(self):
        results = _run_test_levels(download=False)
        self.assertEqual(len(results[0]['pres']), 3)

    def test_fail(self,**kwargs):
        """
        Test info:
            Offline
            Caching
            Narrated
            Failure Test
        """
        LOGGER.info('\n\nTESTING UNAVAILABLE TIMES (Expect failure)\n-------------------------')
        self.assertRaises(ValueError,vrsNarrator._test_fail)

class CacheTests(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        try:
            LOGGER.info('making directory %s',vrsNarrator.DEFAULT_BASE)
            os.mkdir(vrsNarrator.DEFAULT_BASE)
        except OSError as e:
            pass
        LOGGER.info('Filling caches...')
        top_logger = logging.getLogger('virtual_radiosonde_source')
        top_logger.setLevel(logging.WARNING)
        vrs._test_ray(download=True, download_method=DOWNLOAD_METHOD)
        vrsNarrator._test_cache_fill(download_method=DOWNLOAD_METHOD)
        top_logger.setLevel(logging.INFO)
        LOGGER.info('Done filling')

    def test_interface(self):
        results = _run_interface(download=False)
        self.assertEqual(len(results),vrs.NSTEPS)

    def test_cache(self):
        results = _run_cache()
        self.assertGreater(len(results), 0)   

class WeavingTests(unittest.TestCase):

    def setUp(self):
        try:
            LOGGER.info('making directory %s',DEFAULT_BASE)
            os.mkdir(DEFAULT_BASE)
        except OSError as e:
            LOGGER.debug('directory %s already exists',DEFAULT_BASE)
        span = 3
        times = map(lambda time: time['datetime'],vrsNarrator._test_times(span=span))
        cache_dir = DEFAULT_BASE
        try:
            vrsNarrator._check_file_cache(times,cache_dir)
        except ValueError:
            LOGGER.info('Need to fill cache, filling cache...')
            ob = vrsNarrator.VirtualRadiosondeNarrator(cache=DEFAULT_BASE,download=True,
                download_method=DOWNLOAD_METHOD)
            ob.fill_cache(times)


    def test_cache_save(self):
        results = vrsNarrator._test_cache(span=3,save=True)
        self.assertEqual(len(results), 3)

class ReplayTests(unittest.TestCase):


    def setUp(self):
        span = 3
        times = map(lambda time: time['datetime'],vrsNarrator._test_times(span=span))
        cache_dir = DEFAULT_BASE
        try:
            vrsNarrator._check_file_cache(times,cache_dir)
        except ValueError:
            LOGGER.info('Need to fill cache, filling cache...')
            ob = vrsNarrator.VirtualRadiosondeNarrator(cache=DEFAULT_BASE,download=True,
                download_method=DOWNLOAD_METHOD)
            ob.fill_cache(times)
        vrsWeaver._test(span=span,dir=DEFAULT_BASE)

    def test_replay(self):
        """Search entire cache dir for output files from weaver"""
        LOGGER.info('\n\nTESTING REPLAY\n--------------')
        ob = cdfNarrator.cdfNarrator(cache_dir=DEFAULT_BASE)
        results = list(ob.read())
        LOGGER.debug(str(results))
        self.assertGreater(len(results),0)

class ArtistTests(unittest.TestCase):
    """Test artist capabilites"""

    def setUp(self):
        span = artist.DEFAULT_SPAN
        times = map(lambda time: time['datetime'],vrsNarrator._test_times(span=span))
        cache_dir = DEFAULT_BASE
        try:
            vrsNarrator._check_file_cache(times,cache_dir)
        except ValueError:
            LOGGER.info('Need to fill cache, filling cache...')
            ob = vrsNarrator.VirtualRadiosondeNarrator(cache=DEFAULT_BASE,download=True,
                download_method=DOWNLOAD_METHOD)
            ob.fill_cache(times)
    
    @unittest.skipIf(not 'DISPLAY' in os.environ, "Test needs display")
    def test_artist(self):
        LOGGER.info('\n\nTESTING ARTIST\n--------------')
        artist._test()


    @unittest.skipIf(not 'DISPLAY' in os.environ, "Test needs display")
    def test_artist_replay(self):
        LOGGER.info('\n\nTESTING ARTIST REPLAY\n---------------------')
        artist.py.clf()
        vrsWeaver._test(dir=DEFAULT_BASE, span=artist.DEFAULT_SPAN)
        artist._test_replay()

   
def main():
    onlines = unittest.TestLoader().loadTestsFromTestCase(OnlineTests)
    offlines = unittest.TestLoader().loadTestsFromTestCase(OfflineTests)
    caches = unittest.TestLoader().loadTestsFromTestCase(CacheTests)
    saves = unittest.TestLoader().loadTestsFromTestCase(WeavingTests)
    replays = unittest.TestLoader().loadTestsFromTestCase(ReplayTests)
    arts = unittest.TestLoader().loadTestsFromTestCase(ArtistTests)
    LOGGER.info('\n\nONLINE TESTS\n============\n')
    unittest.TextTestRunner(verbosity=2).run(onlines)
    LOGGER.info('\n\nOFFLINE TESTS\n=============\n')
    unittest.TextTestRunner(verbosity=2).run(offlines)
    #LOGGER.info('\n\nINTERNAL CACHE TESTS\n===================')
    #unittest.TextTestRunner(verbosity=2).run(caches)
    LOGGER.info('\n\nWEAVING TESTS\n=============')
    unittest.TextTestRunner(verbosity=2).run(saves)
    LOGGER.info('\n\nREPLAY TESTS\n============')
    unittest.TextTestRunner(verbosity=2).run(replays)
    LOGGER.info('\n\nARTIST TESTS\n============')
    unittest.TextTestRunner(verbosity=2).run(arts)
    return 0
    
if __name__ == '__main__':
    sys.exit(main())
    
