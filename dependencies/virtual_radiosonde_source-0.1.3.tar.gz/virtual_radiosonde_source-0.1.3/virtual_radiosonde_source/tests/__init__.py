"""
All tests are designed for a rsyncing-capable machine.
If you cannot rsync to or from dreadnaught.ssec.wisc.edu then these tests will not work
"""
