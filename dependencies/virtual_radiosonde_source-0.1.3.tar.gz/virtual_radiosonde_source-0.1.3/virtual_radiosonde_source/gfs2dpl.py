#!/usr/bin/env python
# encoding: utf-8
"""
ncep2brf.py
$Id: ncep2brf.py 313 2012-06-20 17:30:45Z rayg $

Purpose: Narrate GFS data for a given time period as a framestream with 3h frames.

TODO: add metadata dictionary in each frame
TODO: build a temporal interpolator for arbitrary time intervals from a clock feed
TODO: 

Created by rayg@ssec.wisc.edu
Copyright (c) 2012 University of Wisconsin SSEC. All rights reserved.
"""
import os, sys
import logging

import numpy as np
from collections import defaultdict
from datetime import datetime, timedelta, date

# identify what files we want to grab profiles from
from gfs_cache import snap_3h, dread0_cache, gfs_cache, DEFAULT_FORMAT as DREAD0_FORMAT, DEFAULT_BASE as DREAD0_BASE
# read an interpolate the files
from grib_gfs import gribfile

LOG = logging.getLogger(__name__)

META = defaultdict(dict)


DEFAULT_CHANNELS = dict(
    temperature = 'Temperature',
    relative_humidity = 'Relative humidity',
    height = 'Geopotential Height',
    # ozone = 'Ozone mixing ratio'
    )

DEFAULT_META = dict(
    temperature = {'units': 'K', 
                    'longname': 'Temperature'},
    relative_humidity = {'units': '%',
                         'longname': 'Relative humdity'},
    height = {'units': 'gpm',
              'longname': 'Geopotential height'},
    # ozone = {'units': 'kg/kg',
    #             'longname': 'Ozone mixing ratio'},
    )

def nwp_frame(object):
    meta = None
    def __init__(self, **kwargs):
        [setattr(self, *kv) for kv in kwargs.items()]        


class gfs2dpl(object):
    """
    bounding_box: ((lon,lat), (lon,lat)) latitude-longitude bounding box
    time_span: (datetime, datetime) UTC (start, end) time span
    keys: set of keys to obtain, or dictionary of gfskey:outputkey pairs
    """
    provides = DEFAULT_META   # metadata dictionary of available channels
    _start = None
    _end = None
    _lon = None
    _lat = None
    _channels = DEFAULT_CHANNELS
    _levels = None
    _remap = True  # whether to remap, interpolating spatially

    @property
    def meta(self):
        return self.provides

    def __init__(self, start, end, lon, lat, levels = None, channels=None, format=None, cache=None, as_dict=False, remap=True, typeOfLevel='isobaricInhPa'):
        """
        Given a timespan, iterate 3h intervals.
        Retrieve best available GFS data for each timestep.
        Return requested channels as an nwp_frame object with channel names as attributes.
        Channels can be name:function, where function returns derived value based on non-derived values.
        If levels[] is provided, 'pressure' channel will include those values.
        Otherwise, pressure_XXXXX will be created for each data channel.

        :param start: starting datetime object in UTC
        :param end: ending datetime object in UTC
        :param lat: latitude to interpolate profiles to
        :param lon: longitude to interpolate profiles to
        :param levels: optional pressure levels (mb, ascending) to interpolate to
        :param channels: optional dictionary of channel_name: GFS-variable-name
        :param format: optional URL format to use to find GFS files, see gfs_cache.py
        :param base: optional caching routine for URLs, see gfs_cache.py
        """
        self._start, self._end, self._lon, self._lat = start, end, lon, lat
        if isinstance(channels, set):
            self._channels = dict( (x,x) for x in channels )
        elif isinstance(channels, dict):
            self._channels = dict(channels)
        self._as_dict = as_dict
        self._levels = levels
        self._format = format
        self._cache = cache
        self._remap = remap
        self._typeOfLevel = typeOfLevel
        
    def files_for_timespan(self, start=None, end=None):
        "yield (datetime, filename) to use for a given time range, such that interpolation to all times in the range can be done"
        if start is None: start = self._start
        if end is None: end = self._end
        when = snap_3h(start)
        end = snap_3h(end, round_up=True)
        while when <= end:
            yield when, gfs_cache(when, format=self._format, cache=self._cache)
            when += timedelta(hours=3)

    def read(self):
        """
        yield a series of nwp_frame objects (or dictionaries, if initialized with as_dict=True)
        """
        lons = np.array([self._lon])
        lats = np.array([self._lat])
        levs = np.array(self._levels) if self._levels is not None else None
        for dt,pn in self.files_for_timespan():
            if pn is None: 
                continue
            LOG.debug('using grib file %s for %s' %(dt,pn))
            gf = gribfile(pn)
            data, deriveds, derived_data = dict(), dict(), dict()            

            LOG.debug('interpolating %d channels' % len(self._channels))
            for k,v in self._channels.items():
                if isinstance(k,tuple):
                    k = '_'.join(k)
                if callable(v):
                    deriveds[k] = v
                elif v is None:
                    continue
                elif not self._remap and self._levels is None:
                    y,v = gf.nearest_to_coords(v, lons=lons, lats=lats)
                    data['pressure_'+k], data[k] = y, v.squeeze()
                elif not self._remap and self._levels is not None:
                    y,v = gf.nearest_to_coords_interp_levels(v, lons=lons, lats=lats, levels=levs)
                    data['pressure_'+k], data[k] = y, v.squeeze()                    
                elif self._levels is None:
                    y,v = gf.interp_to_coords(v, lons=lons, lats=lats)
                    data['pressure_'+k], data[k] = y, v.squeeze()
                else:
                    y,v = gf.interp_to_coords_and_levels(v, lons=lons, lats=lats, levels=levs)
                    data[k] = v.squeeze()
                    data['pressure_'+k] = levs
            if self._levels is not None:
                data['pressure'] = levs

            LOG.debug('calculating %d derived quantities' % len(deriveds))
            LOG.debug('available: %r' % dict((k,v.shape) for k,v in data.items()))
            for k,f in deriveds.items():
                derived_data[k] = f(**data)
            data.update(derived_data)

            timespace = dict(latitude=lats, longitude=lons, time=dt)
            LOG.debug('merging location data: %r' % timespace)
            data.update(timespace)
            yield data if self._as_dict else nwp_frame(meta=self.provides, **data)

    def __iter__(self):
        return self.read()





if __name__=='__main__':
    from pprint import pprint
    logging.basicConfig(level=logging.DEBUG)
    now = datetime.utcnow()
    start, end = now + timedelta(hours=3), now
    from pprint import pprint
    lon = -89.4011
    lat = 43.0731
    ob = gfs2dpl(start=start, end=end, lon=lon, lat=lat, as_dict=True)
    for d in ob:
        pprint(d)
        
        
        
        
        
        
