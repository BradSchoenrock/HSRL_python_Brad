from datetime import datetime, timedelta, time
import sys
import logging
import os
import gfs2dpl
from gfs_cache import cache_dread0_rsync
import gfs_cache
from scipy.interpolate import interp1d,interp2d
import numpy
from collections import namedtuple, Iterable, Counter

logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger(__name__)

SONDE_TIME_UNITS = 'seconds since 2012-09-12 00:00:00 0:00'
SONDE_DP_UNITS = 'C'
SONDE_TEMP_UNITS = 'C'
SONDE_PRES_UNITS = 'hPa'
SONDE_RH_UNITS = '%'
SONDE_ALT_UNITS = 'm'

DEFAULT_BASE = 'tmp_cache'
DEFAULT_FORMAT = 'gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2'
AERI_LAYER_VALUES = numpy.array(list(reversed([2., 3., 4., 5., 7., 10., 15., 20., 25., 30.,
                              50., 75., 100., 125., 150., 175., 200., 250.,
                              300., 350., 400., 450., 500., 550., 600.,
                              620., 640., 660., 680., 700., 720., 740., 760.,
                              780., 800., 820., 840., 860., 880., 900., 905.,
                              910., 915., 920., 925., 930., 935., 940., 945.,
                              950., 955., 960., 965., 970., 975., 980., 985.,
                              990., 995., 1000.0 ])))

DEFAULT_CHANNELS = set(['Temperature','Relative humidity','Geopotential Height'])
KNOWN_CHANNELS = set(['U component of wind','V component of wind',
'Geopotential Height',
#'Ozone mixing ratio', Sometimes?
'Relative humidity',
'Absolute vorticity',
'2 metre temperature',
'Temperature',
'Cloud mixing ratio',
'Vertical velocity'])

class VirtualRadiosondeNarrator():
    """A DPL narrator that iterates across a subset of data and providing channels of interest and abstracting them to a data stream.
    """
    default_sonde_out_vars = {'pressure':'pres','temperature':'tdry','latitude':'lat',
        'dewpoint':'dp','relative humidity':'rh','longitude':'lon','time':'time','height':'alt'}
    #default_sonde_spacetime_vars = {'time':'runTime','date':'dateYYMMDD','latitude':'latitude','longitude':'longitude'}

    def __init__(self,*args,**kwargs):
        """ 
        Initialize the narrator given media information and constraint arguments
        Kwargs:
            channels: specify a dictionary or set of variables to extract from gfs.
            cache: the location the local cache
            format: format string of grib files in cache. 
                Ex. 'gfs.p5.%(yyyy)04d%(mm)02d%(dd)02d_%(hh)02d_%(ooo)03d.ldm.grib2'
            download: Set to true if dreadnaught is to be queried for grib files to put in cache
            levels: Provide custom pressure levels to use. Must be monotonically decreasing in pressure (generally increasing altitude).
            level_type: Type of levels being input
            on_dread: True/False. Use if deployed on dreadnaught no local caching
            mem_cache_size: set max size of mem cache.
            interpolate(False): use linear temporal interpolation as opposed to nearest neighbor
            predict_horizon: the amount of hours into the future before queries will no longer be honored
        """
        cache = kwargs.pop('cache',DEFAULT_BASE)
        self.cache_location = cache
        self.sonde_out_vars = kwargs.pop('sonde_vars',self.default_sonde_out_vars)

        # Sort out channel names
        self.channels = kwargs.pop('channels',DEFAULT_CHANNELS)
        if not isinstance(self.channels,dict):
            self.channels=set(self.channels)

        if kwargs.get('level_type','pressure') == 'pressure':
            LOGGER.debug('Using pressure levels')
            self.levels = numpy.array(kwargs.pop('levels',AERI_LAYER_VALUES))
        else:
            LOGGER.debug('Using non-pressure levels')
            self.levels = list(reversed(range(0,1050,50)))
            self.altitudes = kwargs.pop('levels',None)
            self.channels.add('Geopotential Height')
        self.mem_cache_size = kwargs.pop('mem_cache_size',20)
        gfs2dpl.gribfile.max_cache_size = self.mem_cache_size

        if not os.path.isdir(cache):
            raise EnvironmentError('Cache dir does not exist')

        self.set_download(**kwargs)

        self.kwargs = kwargs
   
    def read(self, timesteps, *args, **kwargs):
        """
        Yield a dictionary containing desired data for every timestep.
        Timesteps is an iterable containing a dictionary with the following keys:
            latitude: float
            longitude: float
            datetime: datetime object
        """
        if hasattr(self.cache,'__enter__'):
            self.cache.__enter__()
        for timestep in timesteps:
            if not isinstance(timestep,dict):
               timestep = timestep._asdict() 
            lat = timestep.get('latitude',None)
            lon = timestep.get('longitude',None)
            if lat > 90 or lat < -90 or lon <-180 or lon >360:
                raise ValueError('-90<latitude<90 , -180<longitude<360')
            datetime = timestep.get('datetime',None)
            self.kwargs.update(kwargs)
            kwargs = self.kwargs
            datetime = self.limit_predictive(datetime,**kwargs)
            if datetime:
                nearest_frames = self.nearest_neighbors(lat,lon,datetime,*args,**kwargs) 
                if kwargs.get('interpolate',False):
                    frame = self.temporal_interpolate(datetime,nearest_frames,**kwargs)
                else:
                    frame = self.nearest(datetime,*nearest_frames)

                if kwargs.get('level_type','pressure') == 'altitude':
                    assert not self.altitudes is None
                    frame = self.interp_to_alts(frame,self.altitudes)
                sonde_frame = self.construct_sonde(frame)
                arg_tuple = namedtuple('VirtualRadiosonde_args',['when','lat', 'lon']+kwargs.keys())
                yield sonde_frame 
            else:
                yield None

        if hasattr(self.cache,'__exit__'):
            self.cache.__exit__()
                

        

    def __iter__(self,*args,**kwargs):
        return self.read(*args,**kwargs)

    def __call__(self,*args,**kwargs):
        return self.read(*args,**kwargs)

    def limit_predictive(self,dt,**kwargs):
        limit = kwargs.get('predict_horizon',24)
        if dt <= (datetime.utcnow() + timedelta(hours=limit)):
            return dt
        LOGGER.warning('Datetime %s is beyond the predict_horizon %s hours',str(dt),limit)
 
    def nearest(self,desired_time,*frames,**kwargs):
        """
        Find the nearest frame temporaly and return it
        """
        if not frames:
            return
        nearest = None
        diff = lambda inframe: numpy.abs(inframe['time'] - desired_time)
        for frame in frames:
            if not nearest or diff(frame) < diff(nearest):
                nearest = frame
        nearest['time'] = desired_time
        return nearest

    def nearest_neighbors(self,lat,lon,datetime,*args,**kwargs):
        """
        Find nearest (surrounding) in time cached grib data.
        """
        #round_up = kwargs.pop('round_up',False)
        levels = kwargs.pop('levels',self.levels)
        cache = kwargs.pop('cache',self.cache)
        format = kwargs.pop('format',self.format)

        #Construct gfs2dpl narrator that will narrate the surrounding files of a time
        narr = gfs2dpl.gfs2dpl(datetime,datetime,
            lon,lat, as_dict=True, levels=levels,format=format,cache=cache,channels=self.channels,remap=True)

        try:
            frames = list(narr)
        except ValueError as e:
            LOGGER.error('Probably invalid channel')
            LOGGER.error(e)
            raise KeyError('Probably invalid channel')

        if len(frames) == 0 or (len(frames) == 1 and frames[0]['time'] != datetime):
            # Need two neighbors, unless right on top of one
            frames = []
            raise ValueError('Time requested: %s is not within file cache' % (datetime.ctime()))
        else:
            #Remove excess pressure variables
            for frame in frames:
                unwanted_keys = set(frame.keys()).difference(
                set(['pressure','time','latitude','longitude']).union(self.channels))
                for key in unwanted_keys:
                    if tuple(key.split('_')) not in self.channels and Counter(key)['_'] < 2:
                        del frame[key]
        
                if 'Temperature' in frame:
                    LOGGER.debug('Converting Temperature from K to C')
                    frame['Temperature'] = self._convert_K2C(frame['Temperature'])
                if 'Dewpoint' in frame:
                    LOGGER.debug('Converting dewpoint temperature from K to C')
                    frame['Dewpoint'] = self._convert_K2C(frame['Dewpoint'])
                    
        
        return frames


    def temporal_interpolate(self,desired_time,nearest_frames,**kwargs):
        """
        Interpolate to desired time using two or more frames.
        Assumes frames have already been interpolated to common pressure levels
        """
        assert isinstance(desired_time,datetime)
        unix = lambda unix: (unix - datetime(1970,1,1)).total_seconds()
        output_frame = nearest_frames[0]
        output_frame.update(time=desired_time)
        desired_time_unix = unix(desired_time)
        common_variables = set(self.channels)
        for frame in nearest_frames:
            common_variables.intersection(set(frame.keys()))
        LOGGER.info('Interpolating %d channels',len(common_variables))

        #Sort frames by time
        nearest_frames = sorted(nearest_frames, key= lambda frame: frame['time'])
        for variable in common_variables:
            LOGGER.debug('Interpolating %s',variable)
            times, values = zip(*[(frame['time'],frame[variable]) for frame in nearest_frames])
            values = numpy.array(values)
            times = map(unix,times)
            var_interp = []
            for level in range(len(values[0])):
                var_interp.append(numpy.interp(desired_time_unix,times,values[:,level]))
            output_frame.update({variable:var_interp})

        return output_frame
                
        

    def construct_sonde(self, frame, sonde_duration=10):
        """
        Transform frame into virtual sonde.
        This involves changing variable names/shapes and deriving time variables.
        """
        epoch_start = datetime(1970,1,1,0,0,0)
        if not isinstance(sonde_duration,datetime):
            sonde_duration = timedelta(seconds=sonde_duration)
        #Common variables in sondes:
        #base_time: int seconds since Unix epoch
        sonde_base_time = int((frame['time'] - epoch_start).total_seconds())

        #time_offset: float[] seconds offset from base_time 
        sonde_time_offsets = numpy.linspace(0,sonde_duration.total_seconds(),frame['pressure'].size)

        #time: float[] seconds since beginning of day
        sonde_time = [(frame['time']+timedelta(seconds=offset)-datetime.combine(frame['time'].date(),time(0,0))).total_seconds() for offset in sonde_time_offsets]
        #lat: float[] latitude in degrees
        sonde_lat = numpy.empty_like(sonde_time)
        sonde_lat[:] = frame['latitude']
        #lon: float[] longitude in degrees
        sonde_lon = numpy.empty_like(sonde_time)
        sonde_lon[:] = frame['longitude']
        #Mapping of gfs names to actual measurements names
        gfs_map = {'time':'time','latitude':'latitude','longitude':'longitude',
        'Temperature':'temperature','pressure':'pressure','Relative humidity':'relative humidity','Geopotential Height':'height'}
        
        #Construct dictionary with data similar to sonde cdf
        sonde = {}
        for variable in frame:
            if variable in gfs_map:
                sonde_name = self.default_sonde_out_vars[gfs_map[variable]]
                sonde.update({sonde_name:frame[variable]})
                LOGGER.debug('gfs variable: %s has been mapped to sonde variable: %s',variable,sonde_name)
            else:
                sonde.update({variable:frame[variable]})
                LOGGER.warning('gfs variable: %s cannot be mapped to sonde variable'+
                '\nUsing name: %s',variable,variable)
        sonde.update(base_time=sonde_base_time)
        sonde.update(time_offset=sonde_time_offsets)
        sonde.update({self.default_sonde_out_vars['time']:sonde_time})
        sonde.update({self.default_sonde_out_vars['latitude']:sonde_lat})
        sonde.update({self.default_sonde_out_vars['longitude']:sonde_lon})
        return sonde

    def fill_cache(self,times):
        """
        Take an iterable of times and fill the local file cache with grib files
        pertaining to those times.
        """
        if self.download:
            times.sort()
            for when in times:
                LOGGER.info('%s',when.ctime())
                gfs_cache.gfs_cache(when, format=self.format, cache=self.cache)
            gfs_cache.gfs_cache(when+timedelta(hours=3), format=self.format, cache=self.cache)
        else:
            LOGGER.warning('Cannot fill cache when download=False')

    def set_download(self,**kwargs):
        """ Set whether to download and the method if any"""
        self.download= download = kwargs.pop('download',False)
        download_method = kwargs.pop('download_method','ftp')
        tunnel = kwargs.pop('tunnel',None)
        cache = kwargs.pop('cache',self.cache_location)

        if download:
            if download_method == 'rsync':
                self.cache=lambda url: cache_dread0_rsync(cache, url)
                self.format = kwargs.pop('format',gfs_cache.URL_FMT_DREAD0_RSYNC)
            if download_method == 'ftp':
                self.cache = gfs_cache.cache_url_ftp(cache)
                #self.cache = lambda url: gfs_cache.cache_url(cache, url)
                self.format = kwargs.pop('format',gfs_cache.URL_FMT_SSEC_GFS)
            if tunnel:
                port = kwargs.pop('port',22)
                LOGGER.info('Using tunnel: %s on port: %d',tunnel,port)
                self.cache=lambda url:gfs_cache.cache_dread0_scp(cache,url,port)
                self.format = (gfs_cache.URL_FMT_DREAD0_SCP[:20] % locals())+\
			gfs_cache.URL_FMT_DREAD0_SCP[20:]
            
        elif kwargs.pop('on_dread',False):
            self.cache=lambda url: gfs_cache.dread0_cache(url)
            self.format = gfs_cache.DEFAULT_FORMAT
        else:
            self.cache=lambda url: self.dread0_cache(url,cache)
            self.format = kwargs.pop('format',DEFAULT_FORMAT)
        self.kwargs = kwargs

    def interp_to_alts(self,frame,altitudes):
        """
        Interpolate frame to altitude levels
        """
        new_frame = {}
        LOGGER.debug('Interpolating frame to altitude levels')
        geopot_hghts = frame['Geopotential Height']
        for key in frame:
            if isinstance(frame[key],Iterable) and len(frame[key])==len(geopot_hghts):
                LOGGER.debug('Interpolating %s to altitude levels',key)
                new_frame[key] = numpy.interp(altitudes,geopot_hghts,frame[key])
            else:
                new_frame[key] = frame[key]
        assert len(new_frame.keys()) == len(frame.keys())
        return new_frame
       
    def check_cache(self,when,lat,lon,**kwargs):
        """
        Check memory cache for cached result.
        Effective if multiple of the similar requests are made
        DEPRECATED
        """
        #Define filter functions
        is_near = lambda key: (numpy.abs(key.lat-lat)**2 + numpy.abs(key.lon-lon)**2) < self.space_threshold**2
        is_recent = lambda key: numpy.abs((when - key.when).total_seconds()) < self.time_threshold
        LOGGER.debug('Time threshold: %s',self.time_threshold)
        #Filter out all not close or recent keys
        cache_hits = filter(is_recent,filter(is_near,CACHE))
        #TODO filter by kwargs too
        if len(cache_hits) > 0:
            LOGGER.warning('Cache hit, using cached value')
            hit = CACHE[cache_hits[0]]
            LOGGER.warning('Time: %s\t(lat,lon): %f, %f',
            cache_hits[0].when.ctime(),cache_hits[0].lat,cache_hits[0].lon)
            LOGGER.debug('Time difference: %s',(cache_hits[0].when - when).total_seconds())
            return hit
        LOGGER.info('Cache miss...computing data')
        return None

    def _convert_K2C(self,K):
        K = numpy.array(K)
        return (K - 273.15)


    def dread0_cache(self, relpath, base=DEFAULT_BASE):
        """
        check local cache
        """
        full_path = os.path.join(base, relpath)
        LOGGER.debug("Checking cache for %s",full_path)
        if os.path.isfile(full_path):
            return full_path
        return None

#CACHE = {}

def _test_now():
    times = []
    gfs2dpl.LOG.setLevel(logging.DEBUG)
    lon = -89.4011
    lat = 43.0731
    for x in range(5):
        times.append({'datetime':datetime.utcnow()+timedelta(hours=x),'latitude':lat,'longitude':lon})
        print (datetime.utcnow()+timedelta(hours=x)).ctime()
    ob = VirtualRadiosondeNarrator()
    for x in ob(times):
        print x
        test = x
    return 0

def _test_alts(**kwargs):
    levels = range(0,15000,50)
    return _test_cache(level_type='altitude',levels=levels,**kwargs)

def _check_file_cache(times,cache_dir,*args,**kwargs):
    """
    Check file cache for needed files, do not compute results
    No guarantees
    """
    format = DEFAULT_FORMAT
    cache = lambda url: gfs_cache.dread0_cache(url,cache_dir)
    for time in times:
        files = list(files_for_timespan(time,format,cache))
        files.sort()
        LOGGER.info('Requested: %s\nUsing: %s',time.ctime(),str(files))
        if not files[0]:
            raise ValueError('Time requested does not appear to be in the cache')

def files_for_timespan(start, format, cache):
    "yield (datetime, filename) to use for a given time range, such that interpolation to all times in the range can be done"
    end = start
    when = gfs2dpl.snap_3h(start)
    end = gfs2dpl.snap_3h(end, round_up=True)
    while when <= end:
        yield gfs_cache.gfs_cache(when, format=format, cache=cache)
        when += timedelta(hours=3)

def _test_fail():
    """Test the failure to find a cached record of requested time"""
    times = []
    gfs2dpl.LOG.setLevel(logging.DEBUG)
    lon = -89.4011
    lat = 43.0731
    for x in range(3,5):
        times.append({'datetime':datetime.utcnow()+timedelta(days=x*365),'latitude':lat,'longitude':lon})
        LOGGER.info((datetime.utcnow()+timedelta(days=x*365)).ctime())
    ob = VirtualRadiosondeNarrator()
    results = []
    for x in ob(times):
        results.append(x)
    return results

def _test_times(**kwargs):
    times = []
    span = kwargs.pop('span',3)
    lon = kwargs.pop('lon',-89.4011)
    lat = kwargs.pop('lat',43.0731)
    LOGGER.info('Using times:')
    for x in range(span):
        times.append({'datetime':datetime.utcnow()+timedelta(hours=x),'latitude':lat,'longitude':lon})
    return times

def _test_cache(**kwargs):
    """Test using local cache without checking dreadnaught for files"""
    span = kwargs.pop('span',3)
    save = kwargs.pop('save',False)
    cache_dir = kwargs.get('cache','./tmp_cache')
    gfs2dpl.LOG.setLevel(logging.INFO)
    lon = -89.4011
    lat = 43.0731
    times = []
    format=DEFAULT_FORMAT
    LOGGER.info('Using times:')
    for x in range(span):
        times.append({'datetime':datetime.utcnow()+timedelta(hours=x),'latitude':lat,'longitude':lon})
        LOGGER.info(str((datetime.utcnow()+timedelta(hours=x)).ctime()))
    times = kwargs.pop('times',times)
    results = []
    ob = VirtualRadiosondeNarrator(**kwargs)
    for x in ob(times):
        results.append(x)
    if save:
        from virtual_radiosonde_source.vrsWeaver import NetcdfWeaver
        LOGGER.info('Saving netcdf to %s...........',cache_dir)
        writer = NetcdfWeaver(dir=cache_dir)
        writer.write(results)
    return results

def _test_cache_fill(**kwargs):
    """Test internal cache filling properties"""
    return _test_cache(download=True,**kwargs)

def _test_download(**kwargs):
    """Test local cache filling"""
    ob = VirtualRadiosondeNarrator(download=True,**kwargs)
    times = [datetime.utcnow()+timedelta(hours=x) for x in range(3)]
    ob.fill_cache(times)
    ob.set_download(download=False)
    times = _test_times(**kwargs)
    return list(ob.read(times))
   
def _test_clock():
    """Test narrator with clock generator where time to be used is provided at runtime by user
    """
    from pprint import pprint
    lon = -89.4011
    lat = 43.0731
    cache_dir = os.path.abspath(DEFAULT_BASE)
    ob = VirtualRadiosondeNarrator()
    for x in ob(times(lat,lon)):
        pprint(x)

def times(lat,lon):
    """Generate from input numbers"""
    while True:
        time = timedelta(hours=input())+datetime.utcnow()
        print time.ctime()
        yield {'datetime':time,'latitude':lat,'longitude':lon}
        

def main():
    import optparse
    parser = optparse.OptionParser()
    parser.add_option('--no-download',action='store_true',default=False,dest='no_download')
    options,args = parser.parse_args()
    if (options.no_download):
        LOGGER.info('Testing narrator with local cache')
        return _test_cache()
    else:
        LOGGER.info('Testing narrator and cache filling')
        return _test_cache_fill()

#if __name__=='__main__':
    #sys.exit(main())
