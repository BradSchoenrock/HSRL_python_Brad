#!/usr/bin/env python# -*- coding: utf-8 -*-
"""
grib_gfs
~~~~~~~~

GFS reader code for fetching profiles at arbitrary locations and interpolating to a preferred vertical sampling.
Also must deal with some GFS files missing pressure levels on some variables (e.g. RH at 20mb missing in test case).

Derived from code from Geoff Cureton, Denny Hackel, Brian Murray.

:copyright: 2012 by University of Wisconsin Regents, see AUTHORS for more details
:license: GPLv3, see LICENSE for more details
"""

__author__ = 'R.K.Garcia <rayg@ssec.wisc.edu>'
__revision__ = '$Id: grib_gfs.py 377 2013-04-09 20:16:11Z bmurray $'
__docformat__ = 'reStructuredText'


import os, sys
import logging, unittest
import pygrib
import numpy as np
from scipy.interpolate import griddata, interp2d

LOG = logging.getLogger(__name__)


import collections
import functools

class memorized(object):
    '''Decorator. Caches a function's return value each time it is called.
    If called later with the same arguments, the cached value is returned
    (not reevaluated).
    '''
    def __init__(self, func, max_size=20):
        self.func = func
        self.cache = collections.OrderedDict()
        self.max_size = max_size
    def __call__(self, *args,**kwargs):
        if not isinstance(args, collections.Hashable):
            # uncacheable. a list, for instance.
            # better to not cache than blow up.
            return self.func(*args)
        if args in self.cache:
            return self.cache[args]
        else:
            max_size = kwargs.pop('max_size',self.max_size)
            if len(self.cache) > max_size:
                #Delete earliest entry if too big
                self.cache.popitem(last=False)
            value = self.func(*args)
            self.cache[args] = value
            return value
    def __repr__(self):
        '''Return the function's docstring.'''
        return self.func.__doc__
    #def __get__(self, obj, objtype):
        #'''Support instance methods.'''
        #return functools.partial(self.__call__, obj)


def _aslayer(arr):
    return arr.reshape( (1,) + tuple(arr.shape) )


class regular_grid(object):
    """
    GFS grib files are on a regularly spaced grid
    this provides calculation tools as needed
    """

    def __init__(self, resolution=0.5):
        self.lon = np.arange(0., 360., resolution)
        self.lat = np.arange(-90., 90.+resolution, resolution)[::-1]
        self.res = resolution
        self.nx = 360.0 / resolution 
        self.ny = 180.0 / resolution + 1

    @staticmethod
    def normalize_lon(lon):
        while lon < 0.0:
            lon += 360.0
        lon = lon % 360.0
        return lon

    def nearest(self, lon, lat):
        lon = regular_grid.normalize_lon(lon)
        lat -= -90.0
        assert(lon >= 0.0 and lon < 360.0)
        assert(lat >= 0.0 and lat <= 180.0)
        return np.round( [lon/self.res, lat/self.res] ).astype(np.int32)




@memorized
class gribfile(object):
    """
    example: 
    fn = '/data/edr/gfs/2012/272/gfs.p5.20120928_00_000.ldm.grib2'
    gf = gribfile(fn)
    rhlev, rh = gf['Relative humidity']
    tlev, t = gf['Temperature']

    tname = 'Temperature'
    lon = -89.4011
    lat = 43.0731
    tnr = gf.nearest_to_coords(tname, lons=[lon], lats=[lat])
    tnt = gf.interp_to_coords(tname, lons=[lon], lats=[lat])
    mbs = [ 100, 200, 300, 600, 900 ]
    trs = gf.interp_to_coords_and_levels(tname, lons=[lon], lats=[lat], levels=mbs)

    Does not work yet: 
    gf = gribfile(fn, name_key = 'shortName')
    dpt = gf['temperatureLayers']

    """
    _index = None 

    def __init__(self, filename, grid=None, resolution=0.5, name_key='name', level_key='typeOfLevel',
                max_size=10):
        self._index = pygrib.index(filename, name_key, level_key)
        if grid is None:
            grid = regular_grid(resolution)
        self.grid = grid        
        self._name_key = name_key
        self._level_key = level_key
        self.cache = collections.OrderedDict()
        self.max_size = max_size

    def __getitem__(self, name):
        return self.get(name)

    def get(self, name, typeOfLevel='isobaricInhPa', slicer=None,**kwargs):
        #check cache first
        if name in self.cache:
            return self.cache[name]
        else:
            max_size = kwargs.pop('max_size',self.max_size)
            if len(self.cache) > max_size:
                #Delete earliest entry if too big
                self.cache.popitem(last=False)
            #Old "get" started here
            name_orig = name
            if isinstance(name, tuple):
                name, typeOfLevel = name
            req = {self._name_key: name, self._level_key: typeOfLevel}
            LOG.debug('accessing grib file index: %r' % req)
            grbs = self._index.select(**req)
            if not callable(slicer):
                levs = {}
                # Find the first grid of desired size for each level
                for g in grbs:
                    if g.level not in levs and g.Ni == 720 and g.Nj == 361:
                        levs[g.level] = g
                levs = [(g['level'], g['values']) for g in levs.values()]
            else:
                levs = [(g['level'], slicer(g['values'])) for g in grbs]
            levs = sorted(levs, key= lambda lv: lv[0])
            y = np.array([l for (l,_) in levs])
            v = np.vstack([_aslayer(a) for (_,a) in levs])
            value = y, np.rollaxis(v, 0, 3)
            self.cache[name_orig] = value
            return value

    def _nearest(self, data, lon, lat):
        x,y = self.grid.nearest(lon=lon, lat=lat)
        LOG.debug( '%fN %fE => %d,%d' % (lat,lon,x,y))
        q = data[y,x]
        return q.reshape( (1,) + q.shape )

    def nearest_to_coords(self, name, lons, lats, **kwargs):
        levels, data = self.get(name,**kwargs)
        return levels, np.vstack([self._nearest(data, lon, lat) for (lon,lat) in zip(lons,lats)])

    def nearest_to_coords_interp_levels(self, name, lons, lats, levels):
        raw_levels, raw_data = self.nearest_to_coords(name, lons, lats)
        if len(raw_levels) <= 1:
            return raw_levels, raw_data
        levels = np.array(levels)
        nprofiles = raw_data.shape[0]
        out = np.empty((nprofiles,) + levels.shape)
        for rnum in range(nprofiles):
            out[rnum,:] = np.interp(levels, raw_levels, raw_data[rnum,:].squeeze())
        return levels, out

    def get_grid(self):
        lats,lons = self._index.select(name='Temperature')[0].latlons()
        return lats[:,0], lons[0,:]

    def interp_to_coords(self, name, lons, lats):
        LOG.debug('interpolating %s @ lon=%r lat=%r' % (name, lons, lats))
        levels, data = self.get(name)
        self.grid.lat, self.grid.lon = self.get_grid()
        lons = np.array(lons) % 360.
        lats = np.array(lats) 
        interpolated = np.hstack([[interp2d(self.grid.lon, self.grid.lat, data[:,:,level])(lons,lats)] for level in range(data.shape[2])])
        return levels, interpolated

    def interp_to_coords_and_levels(self, name, lons, lats, levels):
        LOG.debug('interpolating %s @ lon=%r lat=%r levels:%d' % (name, lons, lats, len(levels)))
        raw_levels, raw_data = self.interp_to_coords(name, lons, lats)
        if len(raw_levels) <= 1:
            return raw_levels, raw_data
        levels = np.array(levels)
        nprofiles = raw_data.shape[0]
        out = np.empty((nprofiles,) + levels.shape)
        for rnum in range(nprofiles):
            out[rnum,:] = np.interp(levels, raw_levels, raw_data[rnum,:].squeeze())
        return levels, out






TEST_FILE = 'gfs.p5.20120928_00_000.ldm.grib2'
TEST_URL='rsync://dreadnaught.ssec.wisc.edu/data/edr/gfs/2012/272/' + TEST_FILE
TEST_PATH = os.path.join(os.environ.get('TMPDIR','/tmp'), TEST_FILE)

class TestGribFile(unittest.TestCase):
    lon = -89.4011
    lat = 43.0731
    levels = [ 100, 200, 300, 600, 900 ]
    path = None
    _gf = None

    def _cached_test_file(self):
        if not os.path.exists(TEST_PATH):
            import subprocess as sp
            LOG.info('downloading test data at %s' % TEST_URL)
            sp.check_call(['rsync', '-uav', TEST_URL, TEST_PATH])
        self.assertTrue(os.path.exists(TEST_PATH))
        return TEST_PATH

    def test_grid(self):
        rg = regular_grid()
        x,y = rg.nearest(lat=36.61, lon=-97.49)
        self.assertEquals(x,525)
        self.assertEquals(y,253)

    @property
    def gf(self):
        if self._gf is None:
            self._gf = gribfile(self.path)
        return self._gf

    def setUp(self):
        self.path = self._cached_test_file()

    def test_open(self):
        q = self.gf
        self.assertTrue(q is not None)

    def test_simple_read(self):
        y,t = self.gf['Temperature']
        self.assertTrue(t.shape == (361, 720, 26))

    def test_nearest(self):
        lon, lat = self.lon, self.lat
        tname = 'Temperature'
        y,tnr = self.gf.nearest_to_coords(tname, lons=[lon], lats=[lat])
        self.assertTrue(tnr.squeeze().shape==(26,))

    def test_spatial(self):
        lon, lat = self.lon, self.lat
        tname = 'Temperature'
        y,tnr = self.gf.interp_to_coords(tname, lons=[lon], lats=[lat])
        self.assertTrue(tnr.squeeze().shape==(26,))

    def test_spatial(self):
        lon, lat = self.lon, self.lat
        tname = 'Temperature'
        y,tsi = self.gf.interp_to_coords(tname, lons=[lon], lats=[lat])
        self.assertTrue(tsi.squeeze().shape==(26,))

    def test_spatial_vertical(self):
        lon, lat = self.lon, self.lat
        tname = 'Temperature'
        mbs = self.levels
        y,trs = self.gf.interp_to_coords_and_levels(tname, lons=[lon], lats=[lat], levels=mbs)
        self.assertTrue(trs.squeeze().shape==(len(mbs),))






#
## FIXME code goes here.
#


def main():
    import optparse
    usage = """
%prog [options] ...

"""
    parser = optparse.OptionParser(usage)
    # parser.add_option('-t', '--test', dest="self_test",
    #                 action="store_true", default=False, help="run self-tests") 
    parser.add_option('-v', '--verbose', dest='verbosity', action="count", default=3,
                    help='each occurrence increases verbosity 1 level through ERROR-WARNING-INFO-DEBUG')
    # parser.add_option('-o', '--output', dest='output',
    #                 help='location to store output')
    # parser.add_option('-I', '--include-path', dest="includes",
    #                 action="append", help="include path")                            
    (options, args) = parser.parse_args()

    # make options a globally accessible structure, e.g. OPTS.
    global OPTS
    OPTS = options

    levels = [logging.ERROR, logging.WARN, logging.INFO, logging.DEBUG]
    logging.basicConfig(level = levels[min(3,options.verbosity)])

    if not args: 
    # if options.self_test:
        unittest.main()
        return 0


    # FIXME main logic
       
    return 0


if __name__=='__main__':
    sys.exit(main())
