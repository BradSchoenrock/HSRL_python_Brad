import numpy
import matplotlib.pyplot as py
import logging
import time
from datetime import timedelta,datetime

logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger(__name__)

DEFAULT_SPAN = 5

class sondeArtist(object):
    """
    Covert radiosonde frame stream into viewable images.
    """
    def __init__(self,source,**kwargs):
        self.source = source
        self.var2extract = kwargs.pop('var2extract',None)
        self.timespan = kwargs.pop('plot_timespan',timedelta(hours=24))

    def render(self,*args,**kwargs):
        #py.clf()
        convert_unix = lambda unix: datetime.utcfromtimestamp(unix)
        self.zvalues = []
        self.source = list(self.source)
        assert len(self.source) >= 1
            
        self.zarray = numpy.array(map(lambda a: a[self.var2extract],self.source)).transpose()
        if self.var2extract in ['tdry','dp']:
            from scipy.constants import C2K
            self.zarray = C2K(self.zarray)
        self.xvalues = numpy.array(map(lambda a: convert_unix(int(a['base_time'])),self.source))
        hours = map(lambda a: a.total_seconds()/3600,self.xvalues - self.xvalues[0])
        if kwargs.pop('yaxis','pres') == 'pres': #pres or alt
            yvalues = 'pres'
            py.ylim([1000,0])
            py.ylabel('Pressure (hPa)')
        else:
            yvalues = 'alt'
            py.ylabel('Altitude (m)')

        #Fix later
        self.yvalues = self.source[0][yvalues]

        self.start = self.xvalues[0]
        self.end = self.start + self.timespan
        from collections import defaultdict
        title_names = defaultdict(lambda :"",{'rh':'Relative Humditiy','tdry':'Ambient Temperature'})
        py.title(title_names[self.var2extract]+' for '+self.start.strftime('%h %d, 20%y'))
        py.xlabel('Time (UTC)')
        assert len(self.zarray.shape) == 2
        yield self._draw_contour(hours,self.yvalues,self.zarray,**kwargs)

    def __iter__(self):
        return self.render()

    def __call__(self,*args,**kwargs):
        return self.render(*args,**kwargs)

    def _draw_contour(self,xvalues,yvalues,zarray,zrange=None,**kwargs):
        LOGGER.info('Drawing contour')
        if zrange is None:
            zrange = range(0,100,10)
        py.contour(xvalues,yvalues,zarray,zrange,
            extend='both',colors='black',
            linestyles='solid',
            antialiased=True)
        cs = py.contourf(xvalues,yvalues,zarray,zrange,extend='both')
        if len(zarray.shape) == 2:
            #LOGGER.debug('Drawing colorbar')
            #colorb = py.colorbar()
            if 'colorbar_label' in kwargs:
                colorb.set_label(kwargs.pop('colorbar_label'))
        py.draw()
        return cs

def _test(**kwargs):
    from virtual_radiosonde_source import vrsNarrator
    var2extract = kwargs.pop('var2extract','rh')
    span = kwargs.pop('span',DEFAULT_SPAN)
    times = vrsNarrator._test_times(span=span)
    ob = vrsNarrator.VirtualRadiosondeNarrator(**kwargs) 
    art = sondeArtist(ob(times),var2extract=var2extract)
    list(art.render(**kwargs))

def _test_replay(cache_dir='./tmp_cache',**kwargs):
    from virtual_radiosonde_source import cdfNarrator
    var2extract = kwargs.pop('var2extract','rh')
    if kwargs.pop('fill',False):
        from virtual_radiosonde_source import vrsWeaver
        vrsWeaver._test(download=True,**kwargs)
    ob = cdfNarrator.cdfNarrator(cache_dir=cache_dir)
    art = sondeArtist(ob.read(),var2extract=var2extract,**kwargs)
    list(art.render(**kwargs))

if __name__ == '__main__':
    _test(download=True,download_method='rsync')
