from vrsNarrator import VirtualRadiosondeNarrator
from vrsNarrator import logging
from vrsNarrator import datetime, timedelta
from vrsNarrator import DEFAULT_BASE
from collections import namedtuple
from vrsWeaver import NetcdfWeaver

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)

class VirtualRadiosonde(VirtualRadiosondeNarrator):
    """
    Returns frames with data resembling a single radiosonde
    when given a time and location.
    Inherits from VirtualRadiosondeNarrator to provide data.
    """

    def __call__(self,when,lat,lon, *args, **kwargs):
        """
        Read the media and return a data frame
        """
        timestep = {'datetime':when,'latitude':lat,'longitude':lon}
        #Just run iterator once.
        LOGGER.info('Using single time, lat, lon')
        results = []
        for x in self.read(list([timestep]),*args,**kwargs):
            if x:
                results.append(x)
            else:
                raise ValueError('Cannot compute frame')
        results = results[0]
        assert isinstance(results,dict), 'results are %s' % type(results)
        arg_tuple = namedtuple('VirtualRadiosonde_args',['when','lat', 'lon']+kwargs.keys())
        return results 

NSTEPS = 40

def _test_ray(cache_dir=DEFAULT_BASE,path=None,**kwargs):
    """
    Test pattern for Virtual Radiosonde Source as used by LIDAR science code
    :param cache_dir: where to look for GFS data
    :param path: sequence of footprint
    """
    from numpy import arange, linspace
    from pprint import pformat
    results = []
    save = kwargs.pop('save',False)
    footprint = namedtuple('footprint', 'time lat lon')
    times = [datetime.utcnow()+timedelta(hours=x) for x in range(NSTEPS)]      
    lats = linspace(30., 40., NSTEPS)
    lons = linspace(-90., -70., NSTEPS)
    path = [footprint(*q) for q in zip(times, lats, lons)]
    try:
        # construct a virtual radiosonde source
        # default time_threshold and space_threshold determine whether cached values need recomputing
        # (this is preferred over returning an expiration threshold to the caller which it would then
        #  have to consult before asking the VRS for a new value)
        # thresholds are in seconds / degrees
        # if a preferred pressure scale is desired, it should be an input parameter
        vrs = VirtualRadiosonde(cache=cache_dir,**kwargs)
    except EnvironmentError as ohnoes:
        LOGGER.error(ohnoes)
        LOGGER.error("cache environment is not usable")
        return
    
    for point in path:
        when, lat, lon = point
        LOGGER.info('Input: %s',pformat(point))
        try:
            profiles = vrs(when, lat, lon) # raises ValueError if time is OOB
        except ValueError as outatime:
            LOGGER.error("Error: %s",outatime)
            continue
        results.append(profiles)
        log = ''
        log += pformat("\nP:\n")
        log += pformat(profiles['pres'])        
        log += pformat('\nRH:\n')
        log += pformat(profiles['rh'])
        log += pformat('\nT:\n')
        log += pformat(profiles['tdry'])
    if save: 
        LOGGER.info('Saving netcdf to %s...........',cache_dir)
        writer = NetcdfWeaver(dir=cache_dir)
        writer.write(results)
    return results
