import numpy
import logging
from netCDF4 import Dataset as ncdf
from datetime import datetime,timedelta
import os

logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger(__name__)
sonde_units_dict = {'base_time':'seconds since 1970-1-1 0:00:00 0:00','lat':'degrees','lon':'degrees','pres':'hPa',
'tdry':'C','dp':'C','rh':'%%','time':'seconds since %(ctime_date)s','time_offset':'seconds since %(base_time)s',
'alt':'m'}
epoch = datetime(1970,1,1,0,0)
DEFAULT_FORMAT = 'vrs_%(time)s_%(lat)f_%(lon)f.cdf'

class NetcdfWeaver:
    
    def __init__(self,*args,**kwargs):
        self.dir = kwargs.pop('dir','./')
    
    def write(self,generator,*args,**kwargs):
        name = kwargs.pop('name_fmt',DEFAULT_FORMAT)
        dir = kwargs.pop('dir',self.dir)
        name = os.path.join(dir,name)
        for file in generator:
            basetime = (timedelta(seconds=file['base_time'])+epoch)
            date = basetime.replace(hour=0,minute=0,second=0,microsecond=0)
            file_name = (name % {'time':basetime.isoformat(),'lat':file['lat'][0],'lon':file['lon'][0]}).replace(':','-')
            LOGGER.info('Writing file %s',file_name)
            netcdf_file = ncdf(file_name,'w',clobber=True,format='NETCDF3_CLASSIC')
            netcdf_file.createDimension('time',None)
            for variable in file:
                LOGGER.debug("writing variable %s",variable)
                if isinstance(file[variable],int):
                    var = netcdf_file.createVariable(variable,'i4')
                    LOGGER.debug('assigning value of %s',str(file[variable]))
                    var.assignValue(int(file[variable]))
                else:
                    var = netcdf_file.createVariable(variable,numpy.array(file[variable]).dtype,('time',))
                    var[:] = file[variable][:]
                    qc_var = netcdf_file.createVariable('qc_'+variable,numpy.array(file[variable]).dtype,('time',))
                    qc_var[:] = 0
                var.units = sonde_units_dict[variable] % {'base_time':basetime.ctime(), 'ctime_date':date.ctime()}
            netcdf_file.close()

def test(dictionaries):
    ob = NetcdfWeaver()
    ob.write(dictionaries)

def _test(**kwargs):
    from virtual_radiosonde_source import vrsNarrator
    span = kwargs.pop('span',12)
    times = vrsNarrator._test_times(span=span)
    ob = vrsNarrator.VirtualRadiosondeNarrator(**kwargs)
    weaver = NetcdfWeaver(**kwargs)
    weaver.write(ob.read(times),**kwargs)
