import numpy
from netCDF4 import Dataset
from virtual_radiosonde_source import vrsWeaver
import os
import re
import logging
logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger(__name__)

class cdfNarrator(object):
    
    def __init__(self,*args,**kwargs):
        self.cache = kwargs.pop('cache_dir','./')
        format = kwargs.pop('format',vrsWeaver.DEFAULT_FORMAT)
        self.filelist = _compile_file_list(self.cache,format)
    
    def read(self,*args,**kwargs):
        for file in self.filelist:
            netcdf = Dataset(os.path.join(self.cache,file),format='NETCDF3')
            basetime = netcdf.variables['base_time'].getValue()[0]
            del netcdf.variables['base_time']
            frame = dict(zip(netcdf.variables,map(lambda var: netcdf.variables[var][:], netcdf.variables)))#
            frame.update({'base_time':basetime})
            yield frame
            netcdf.close()


def _compile_file_list(dir,format):
    format = format.replace(')f',')s')
    pattern = format % {'lat':'.*','lon':'.*','time':'.*'}
    LOGGER.debug('search pattern: %s',pattern)
    filelist = os.listdir(dir)
    regex = re.compile(pattern)
    filelist = filter(lambda file: True if regex.search(file) else False,filelist)
    filelist.sort()
    return filelist

def _test():
    ob = cdfNarrator(cache_dir='./tmp_cache')
    return list(ob.read())
