Virtual Radiosonde From NWP
--------------------------

What is it?
-----------

Virtual Radiosonde From NWP is designed to be an extension of current
gfs-based data providers. VRS processes the data to create a "virtual
radiosonde" with the properties of a radiosonde for use in place of
conventional radiosonde sources. GFS data is assumed to be provided by 
dreadnaught and if VRS is deployed on dreadnaught file downloads are 
not necessary. However, if VRS is deployed to an external machine, the 
needed grib files will be downloaded to a local cache for use offline.

Installation
------------

VRS may be installed as a python package using setuptools.
python setup.py install

Dependencies
------------

python >= 2.6
numpy
scipy
setuptools
pygrib
    REQUIRES grib-api c lib
    REQUIRES pyproj
datetime
netCDF4-python
mpl_toolkits.basemap


Usage
-----

The VRS package contains:
    Simple usage wrapper vrs.py
        This is a front-end of the vrsNarrator that obscures the DPL
        role and acts as a callable class.

    DPL-Narrator vrsNarrator.py
        This is an implementation of DPL narrator that piggybacks on
        gfs2dpl. It provides radiosonde frames to be either directly
        used in another python module or saved by the weaver.

    DPL-Weaver vrsWeaver.py
        This is a netcdf weaver to be used in conjunction with vrsNarrator. It
        writes netcdf3 files containing variables and data similar to
        radiosonde netcdfs.
    
    DPL-Artist artist.py
        The artist's role is to convert a frame stream to imagery.

    DPL-Narrator cdfNarrator.py
        Searches a directory for output of vrsWeaver and replays
        the original narration in order from earliest to latest.

    The default mode of all modules is offline. Therefore in order to process data,
the file cache must be filled. There are several to fill the cache.  The
simplest of all methods it to run the source with all the desired time regions
while have download=True for the initizilation of the module object.  This
however can take a very long time especially with a large number of times.  An
alternative is to use the fill_cache function in a VirtualRadiosondeNarrator or
VirtualRadiosonde object to fill the cache.
    In addition to a file cache there is an internal memory cache responsible
for storing the results of each request dependent on time and location. When a
request is recieved that is within the time_threshold and space_threshold, VRS
returns the same result as previously computed. This process is much faster than
retrieving and recomputing from the file cache, but it is unavailable for
requests with custom levels or channels for consistancy.


Accessing Data
--------------

To fill the cache, data must be downloaded from somewhere by some method.

If you have permissions to rsync to directly to dreadnaught:
    Use download_method='rsync'
    virtual_radiosonde_source should work fine, you might have to tweak cache
    and format settings. Rsync has a slight speed advantage over ftp.

If you DON'T have permissions to rsync to dreadnaught but have ssh access:

    Use scp access method:
        Specify in kwargs when initializing:
            tunnel=<user@host>
            port=<port to use>

    OR

    Mount dreadnaught as a NFS (ex. sshfs dreadnaught ./dreadnaught_mounted)
    Specify in kwargs when initializing:
        cache='/path/to/dreadnaught/data'
        format=vrsNarrator.gfs_cache.DEFAULT_FORMAT

If you don't have rsync or ssh you can use ftp, the default method. :
    download_method='ftp'
