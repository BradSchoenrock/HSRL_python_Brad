from setuptools import setup

def readme():
    with open('README.txt') as f:
        README=f.read()
        return README

setup(name='virtual_radiosonde_source',
      version='0.1.3',
      description='Provides simulated radiosonde data to LIDAR processing software by preloading NWP data before departure.',
      long_discription=readme(),
      author='Coda Phillips',
      author_email='cmphillips5@wisc.edu',
      packages=['virtual_radiosonde_source'],
      install_requires=[
        'python>=2.6',
        'numpy',
        'scipy',
        'pyproj',
        'pygrib',
        'matplotlib',
        'netCDF4'],
      tests_require=['nose'],
      test_suite='nose.collector')
      
