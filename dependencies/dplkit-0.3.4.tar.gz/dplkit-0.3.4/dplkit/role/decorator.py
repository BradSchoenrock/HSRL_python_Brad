#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
dplkit.role.decorator
~~~~~~~~~~~~~~~~~~~~~

Decorators used to mix-in standard protocols

:copyright: 2013 by University of Wisconsin Regents, see AUTHORS for more details
:license: GPLv3, see LICENSE for more details
"""
__author__ = 'rayg'
__docformat__ = 'reStructuredText'

import os, sys
import logging, unittest
from functools import wraps
import traceback
import weakref
from collections import OrderedDict

LOG = logging.getLogger(__name__)

def meta(self):
    return self.provides

class thing(object):
    def __init__(self,fieldname,initval=None,readonly=False,raiseAttributeErrorOnDefault=False,requiredType=None):
        self.initvalue=initval
        self.fieldname=fieldname
        self.readonly=readonly
        self.requiredType=requiredType
        self.raiseAttributeErrorOnDefault=raiseAttributeErrorOnDefault

    def __get__(self, obj, type=None):
        if not hasattr(obj,self.fieldname):
            if self.raiseAttributeErrorOnDefault:
                raise AttributeError(repr(obj)+" doesn't have attribute "+self.fieldname)
            return self.initvalue #this doesn't copy, so it should be immutable
        return getattr(obj,self.fieldname)

    def __set__(self, obj, value):
        assert(not self.readonly)
        assert(self.requiredType==None or isinstance(value,self.requiredType))
        assert(value==None or not value is self.initvalue)
        setattr(obj,self.fieldname,value)

    def __delete__(self, obj):
        if hasattr(obj,self.fieldname):
            delattr(obj,self.fieldname)

def actorIsStateful(actor):
    return hasattr(actor,'isStateful') and actor.isStateful==True

def upstreamIsStateful(actor):
    if not hasattr(actor,'isStateful'):
        return False
    assert(hasattr(actor,'getattrexposed'))
    d=actor.getattrexposed('isStateful')
    for k,v in d.items():
        if v:
            return True
    return False

def is_stateful(maybecls=None,startingValue=True):
    """
    Stateful and Stateless Actors are important to discern.

    By default, Actors are assumed to be stateless. This means that multiple calls to iter(object) will return independant objects that generate the same stream when iterated.
    This also means that any instance of 'for x in obj:', which implicitly calls iter(obj) will start from the beginning of the stream.
    Actors that are stateful are expected that there will only be one consumer. multiple calls to iter(object) may or may not work, but a frame that appears on one won't appear
    on any other. Instances of 'for x in obj:' will not start at the beginning of the stream, but continue from the last point.

    Optional parameter of startingValue, if set to True (default), is permenant. If set to False, this can be changed per instance by setting obj.isStateful=True
    """
    def realstatefulcall(cls):
        if not issubclass(cls,object):
            raise RuntimeError('class '+repr(cls)+" isn't an object")
        if hasattr(cls,'isStateful') and not isinstance(getattr(cls,'isStateful'),thing):
            raise RuntimeError('class ' + repr(cls) + ' already has isStateful!')
        sv=startingValue if startingValue!=None else True
        cls.isStateful = thing('__p_stateful',initval=sv,readonly=sv==True,requiredType=bool,raiseAttributeErrorOnDefault=sv!=True)
        return exposes_attrs_in_chain(['isStateful'])(cls)
    if maybecls==None:
        return realstatefulcall
    return realstatefulcall(maybecls)

def removes_statefulness(maybecls=None):
    """
    Stateful and Stateless Actors are important to discern.

    By default, Actors are assumed to be stateless. This means that multiple calls to iter(object) will return independant objects that generate the same stream when iterated.
    This also means that any instance of 'for x in obj:', which implicitly calls iter(obj) will start from the beginning of the stream.
    Actors that are stateful are expected that there will only be one consumer. multiple calls to iter(object) may or may not work, but a frame that appears on one won't appear
    on any other. Instances of 'for x in obj:' will not start at the beginning of the stream, but continue from the last point.

    This decorator is for actors that explicitly collect data from a stateful stream allowing it to be reused multiple times with the same result
    """
    def realstatefulcall(cls):
        if not issubclass(cls,object):
            raise RuntimeError('class '+repr(cls)+" isn't an object")
        if hasattr(cls,'isStateful') and not isinstance(getattr(cls,'isStateful'),thing):
            raise RuntimeError('class ' + repr(cls) + ' already has isStateful!')
        cls.isStateful = thing('__p_stateful',initval=False,readonly=True,requiredType=bool,raiseAttributeErrorOnDefault=False)
        return exposes_attrs_in_chain(['isStateful'])(cls)
    if maybecls==None:
        return realstatefulcall
    return realstatefulcall(maybecls)

def has_provides(cls):
    if not issubclass(cls,object):
        raise RuntimeError('class '+repr(cls)+" isn't an object")
    cls.meta = property(meta)
    if  hasattr(cls,'provides') and not isinstance(getattr(cls,'provides'),thing):
        raise RuntimeError('class ' + repr(cls) + ' already has provides!')
    cls.provides = thing('__p_provides',requiredType=dict,raiseAttributeErrorOnDefault=True)
    return exposes_attrs_in_chain(['provides'])(cls)


def has_requires(cls):
    if not issubclass(cls,object):
        raise RuntimeError('class '+repr(cls)+" isn't an object")
    if hasattr(cls,'requires') and not isinstance(getattr(cls,'requires'),thing):
        raise RuntimeError('class ' + repr(cls) + ' already has requires!')
    cls.requires = thing('__p_requires',requiredType=dict,raiseAttributeErrorOnDefault=True)
    return exposes_attrs_in_chain(['requires'])(cls)

import threading


def describe(frame,nestedclasses=None,getattributes={},nesting=None,frameclass=dict):
            d=frame
            if nesting==None:
                nesting=(nestedclasses!=None)
            if nestedclasses==None:
                nestedclasses=[frameclass]
            ret={}
            if d==None:
                return ret
            if not isinstance(frame,dict):
                d=None
                for c in nestedclasses:
                    if isinstance(frame,c):
                        if c in getattributes:
                            d=getattributes[c](frame)
                        else:
                            d=vars(frame)
                        break
            if d!=None:
                for k,v in d.items():
                    if k.startswith('_'):
                        continue
                    shp=tuple()
                    if hasattr(v,'shape'):
                        shp=v.shape
                    else:
                        try:
                            shp=(len(v),)
                        except:
                            pass
                    ret[k]={'shortname':k,'type':type(v),'shape':shp}
                    if nesting:
                        for c in nestedclasses:
                            if isinstance(v,c):
                               ret[k]=describe(v,nestedclasses,getattributes,nesting)
                               break
            return ret


class __autoprovidesbase(object):

    class realprovides(object):
        def __init__(self,n=[],g={},nesting=False,orig_iter=None,reuseGenerator=None):
            self.orig_iter=orig_iter
            self.nestedclasses=n if isinstance(n,list) else [n]
            self.getattributes=(g if isinstance(n,list) and isinstance(g,dict) else {type(n):g}) if g!=None else {}
            self.nesting=nesting
            self.reuseGenerator=reuseGenerator

        def describe(realme,fr):
            return describe(fr,realme.nestedclasses,realme.getattributes,realme.nesting)

        def runProvides(realme,self,dpiter,dpprior):
            priorframe=None
            while priorframe==None:
                try:
                    priorframe=dpiter.next()
                    if self._dp_shortcircuit:
                        assert(self._dp_ranprovides)
                        self._dp_shortcircuit=False
                        raise StopIteration #break out, the generator set it for us, and this None is to be ignored
                except StopIteration:
                    break
                except:
                    print 'Got Exception in autoprovides'
                    print traceback.format_exc()
                    with self._dp_provideslock:
                        self._dp_providesrunning=False
                        self._dp_provideslock.notify_all()
                    raise
                else:
                    dpprior.append(priorframe)
            with self._dp_provideslock:
                if not self._dp_ranprovides:
                    realme.setProvidesUsing(self,priorframe)
                self._dp_providesrunning=False
                self._dp_provideslock.notify_all()

        def readyRunProvides(realme,self,dpiter,dpprior,tryReuse=True):
            assert(not self._dp_providesrunning)
            self._dp_lockedthread=threading.currentThread()
            self._dp_providesrunning=True
            if tryReuse and realme.reuseGenerator(self):
                self._dp_iterator=dpiter
                self._dp_priorframes=dpprior
            return True

        def __get__(realme,self,type=None):
            if self==None:
                return realme
            if not self._dp_ranprovides:
                #print 'locking',self,realme,realme.nestedclasses,realme.getattributes
                mustrunprovides=False
                with self._dp_provideslock:
                    if self._dp_providesrunning:
                        if threading.currentThread()==self._dp_lockedthread:
                            print 'Deadlock on auto provides for class '+repr(self.__class__)+' instance '+repr(self)+". This probably occurred because a generator function failed prior to this moment"
                            raise RuntimeError('Deadlock on auto provides for class '+repr(self.__class__)+' instance '+repr(self))
                    #return None
                        while not self._dp_ranprovides:
                            self._dp_provideslock.wait()
                        return self._dp_provides
                    elif not self._dp_ranprovides:
                        #self._dp_provideslock.acquire()
                        dpiter=realme.orig_iter(self)
                        dpprior=[]
                        mustrunprovides=realme.readyRunProvides(self,dpiter,dpprior)
                #print 'locked',self,realme,realme.nestedclasses,realme.getattributes
                if mustrunprovides:
                    realme.runProvides(self,dpiter,dpprior) #do this outside of lock
            return self._dp_provides

        def setProvidesUsing(realme,self,frame):
            if self._dp_provides==None:
                self._dp_provides=realme.describe(frame)
            self._dp_ranprovides=True
            self._dp_provideslock.notify_all()


 
    def __init__(self,nestedclasses,getattributes,nesting,reuseGenerator):
        self.nestedclasses=nestedclasses
        self.getattributes=getattributes
        self._reuseGenerator=reuseGenerator
        self.nesting=nesting
        if self._reuseGenerator==None:
            envdef=os.getenv('REUSE_DPL_AUTOPROVIDES_ITERATOR')
            if envdef==None:
                self._reuseGenerator=False
            elif envdef.lower() in ('no','false','disable','0'):
                self._reuseGenerator=False
            elif envdef.lower() in ('yes','true','enable','1'):
                self._reuseGenerator=True
            else:
                raise RuntimeError('REUSE_DPL_AUTOPROVIDES_ITERATOR has an unrecognized setting of "'+envdef+'"')

    def reuseGenerator(self,actor=None):
        ret=self._reuseGenerator
        if not ret and actor!=None:
            ret=actorIsStateful(actor)
        return ret

    def __call__(meself,original_class):
        orig_init = original_class.__init__
        orig_iter = original_class.__iter__
        # make copy of original __init__, so we can call it without recursion

        def __init__(self, *args, **kws):
            self._dp_iterator=None
            self._dp_priorframes=None
            self._dp_provides=None
            self._dp_ranprovides=False
            self._dp_providesrunning=False
            self._dp_provideslock=threading.Condition()
            self._dp_lockedthread=None
            self._dp_shortcircuit=False
            orig_init(self, *args, **kws) # call the original __init__

        def itergen(pf,i):
                if pf!=None:
                    for f in pf:
                        yield f
                    while len(pf)>0:
                        pf.pop()
                for f in i:
                    yield f

        def fakeiter(self):#this returns a seperate function because generators don't actually run until being iterated on. jsut to make sure _dp_* are cleared as soon as __iter__ is called
                i=self._dp_iterator
                pf=self._dp_priorframes
                self._dp_iterator=None
                self._dp_priorframe=None
                return itergen(pf,i)
 
        def setProvidesUsing(self,frame):
            with self._dp_provideslock:
                type(self).provides.setProvidesUsing(self,frame)

        def __iter__(self):
            mustrunprovides=False
            with self._dp_provideslock:#.acquire()
                while self.providesRunning:
                    self._dp_provideslock.wait()
                if self._dp_iterator!=None:
                    ret=fakeiter(self) #reuse the old generator object used to get a frame to describe for provides
                else:
                    ret=orig_iter(self)
                if not self._dp_ranprovides and not self.providesRunning:
                    priorlist=[]
                    mustrunprovides=original_class.provides.readyRunProvides(self,ret,priorlist,tryReuse=False)#will always reuse here
                #print 'locked',self,realme,realme.nestedclasses,realme.getattributes
            if mustrunprovides:
                original_class.provides.runProvides(self,ret,priorlist) #do this outside of lock
                return itergen(priorlist,ret)

            assert(not self._dp_shortcircuit and not self._dp_providesrunning)
            return ret

        def providesRunning(self):
            return self._dp_providesrunning

        def doingShortCircuit(self):
            self._dp_shortcircuit=True

        original_class.__init__ = __init__ # set the class' __init__ to the new one
        original_class.__iter__ = __iter__
        original_class.provides=meself.realprovides(meself.nestedclasses,meself.getattributes,nesting=meself.nesting,orig_iter=orig_iter,reuseGenerator=meself.reuseGenerator)
        original_class.setProvidesUsing=setProvidesUsing
        original_class.providesRunning=property(providesRunning)
        original_class.doingShortCircuit=doingShortCircuit
        return original_class


def autoprovidenested(func=None,nestedclasses=[dict],getattributes={},reuseGenerator=None):
    """
    decorator to autodiscover nested frame descriptions. MUST use 'frameclass=xxxx' notation on decriptor parameters if you change defaults
    :param nestedclasses:  frame class to descend, or ordered list of classes, if non default.  default is 'dict'
    :param getattributes: callable object to extract a dictionary from the frame class so it can explore it, or dictionary keyed to classes. default is to use 'vars()' if not specifed
    :param reuseGenerator: if True, will reuse the generator use to create the provides dictionary. if False, will not. Default is False unless a stateful actor is in the path. default can be overridden REUSE_DPL_AUTOPROVIDES_ITERATOR environment not set
    :return:
    """
    obj=__autoprovidesbase(nestedclasses,getattributes,nesting=True,reuseGenerator=reuseGenerator)
    if(func==None):
        return obj
    return obj(func)

def autoprovide(func=None,frameclass=dict,getattributes=None,reuseGenerator=None):
    """
    decorator to autodiscover frame descriptions. MUST use 'frameclass=xxxx' notation on decriptor parameters if you change defaults
    :param frameclass: frame class to descend, if non default.  default is 'dict'
    :param getattributes: callable object to extract a dictionary from the frame class so it can explore it. default is to use 'vars()' if not specifed
    :param reuseGenerator: if True, will reuse the generator use to create the provides dictionary. if False, will not. Default is False unless a stateful actor is in the path. default can be overridden with REUSE_DPL_AUTOPROVIDES_ITERATOR environment not set
    :return:
    """
    obj=__autoprovidesbase(frameclass,getattributes,nesting=False,reuseGenerator=reuseGenerator)
    if(func==None):
        return obj
    return obj(func)

#these are exposed class wide, not per instance
def exposes_attrs_in_chain(exposed_attrs):
    class attribute_list(object):
        def __init__(self,klass,fieldname,value):
            self.originalval=value
            self.superval=None
            self.value=set(value)
            if hasattr(klass,fieldname):
                sv=getattr(klass,fieldname)
                if isinstance(sv,tuple):
                    self.superval=set(sv)
                elif isinstance(sv,set):
                    self.superval=sv
                elif isinstance(sv,self.__class__):
                    self.superval=sv.value
                else:
                    raise RuntimeError('Field '+fieldname+' of class (or superclass thereto) '+repr(klass)+' already set to non attribute_list value. is a '+repr(type(sv)))
                self.value=self.value.union(self.superval)
            #print 'class',klass,'exposes fields',self.value

        def __get__(self,otherself,type=None):
            return self.value

    def decorator(cl):
        cl.___exposed_attrs = attribute_list(cl,'___exposed_attrs',exposed_attrs)
        return cl
    return decorator

def donone():
    return None

def exposes_attrs_of_field(fieldname):
    """
    decorator to allow class instances to return attributes of one of its fields, where the name is not already assigned
    :param fieldname: name of the attribute field which we should source attributes from if not already defined
    :return:
    """
    def decorator(cl):
        oldcget = getattr(cl, '__getattr__', None)
        if oldcget==None:
            oldcget = getattr(cl, '__getattribute__', None)#first layer
        #else:
        #    print 'Nested use of exposes_attrs_of_field'
        #print oldcget
        if oldcget==None:
            raise RuntimeError(repr(cl)+" isn't a new 'object' type class. FIX IT!")
        olddeep = getattr(cl, '___exposed_attrs_child',None)
        oldgetallattr = getattr(cl, 'getattrexposed',None)

        def getallattr(self,name):
            if oldgetallattr==None:
                parent=OrderedDict()
            else:
                parent=oldgetallattr(self,name)
            x=getexposed(self,name)
            child=OrderedDict()
            if x!=None:
                child[fieldname]=x
            parent.update(child)
            return parent

        def getexposed(self,name,exception=None):
            if name.startswith('_') or (self.___exposed_attrs_child!=None and name not in self.___exposed_attrs_child):
                if exception!=None:
                    raise exception
                return None
            #print "getting",fieldname
            try:
                if not hasattr(self,fieldname):
                    #print self,"doesn't have",fieldname
                    if exception!=None:
                        raise exception #don't let this have any chance to go recursive
                    return None
                source = getattr(self,fieldname)
                #print 'getattr recursively returning',name,'of',fieldname,'(',source,')','from',self
                return getattr(source, name)
            except AttributeError as ae:
                #print ae
                if exception!=None:
                    raise exception
                return None

        def _getattr_(self, name):
            #if oldcget is not None:
            try:
                #if not name.startswith('_'):
                #    print 'Gettattr on',self,'field',name 
                return oldcget(self, name)
            except AttributeError as e:
                return getexposed(self,name,exception=e)

 
        def exposed_deep(self):#returns exposed attributes for all lower exposed features, or None if someone doesn't, thus exposes all
            source = self.__getattribute__(fieldname)
            if hasattr(self,'___exposed_attrs_deep_cached'):
                if self.___exposed_attrs_deep_cached_source() is source and self.___exposed_attrs_deep_cached_sourceNone == (source==None):
                    return self.___exposed_attrs_deep_cached
            setattr(self,'___exposed_attrs_deep_cached_source',donone if source==None else weakref.ref(source))
            setattr(self,'___exposed_attrs_deep_cached_sourceNone',source==None) #weakref becomes None if the object is invalid. if source were set to None, and that object released, need to know.
            #print 'exd'
            if not hasattr(source,'___exposed_attrs_all'):
                setattr(self,'___exposed_attrs_deep_cached',None)
                return None#all are exposed below us
            ret=source.___exposed_attrs_all #return all of what the child exposes
            if not olddeep:
                setattr(self,'___exposed_attrs_deep_cached',ret)
                return ret
            r=olddeep.__get__(self)
            if r==None:
                setattr(self,'___exposed_attrs_deep_cached',None)
                return None
            ret=ret.union(r)
            setattr(self,'___exposed_attrs_deep_cached',ret)
            return ret

        def exposed_all(self):#union of deep and what this exposes (if defined), or None if this doesn't say
            #print 'exa'
            if hasattr(self,'___exposed_attrs_all_cached'):
                return self.___exposed_attrs_all_cached
            if not hasattr(self,'___exposed_attrs') or self.___exposed_attrs==None:
                #setattr(self,'___exposed_attrs_all_cached',None)
                return None #at this level, all are exposed. lower, maybe not
            r=self.___exposed_attrs_child
            if r==None:
                #setattr(self,'___exposed_attrs_all_cached',None)
                return None
            if self.__exposed_attrs==None:
                #setattr(self,'___exposed_attrs_all_cached',None)
                return None
            ret=r.union(self.___exposed_attrs)
            #setattr(self,'___exposed_attrs_all_cached',ret)
            return ret

        cl.___exposed_attrs_all = property(exposed_all)
        cl.___exposed_attrs_child = property(exposed_deep)
        cl.__getattr__ = _getattr_
        cl.getattrexposed=getallattr
        return cl
    return decorator



class test_expose_attrs1(unittest.TestCase):

    class any(object):
        pass

    @exposes_attrs_of_field('src')
    class uncanny(object):
        src = None

        def __init__(self, _src):
            self.src = _src

    def test1(self):
        a = self.any()
        a.q = 'q'
        b = self.uncanny(a)
        self.assertEqual(b.q, a.q, 'check attribute passthrough')

    def test2(self):
        a = self.any()
        a.q = 'q'
        b = self.uncanny(a)
        b.q = 'r'
        self.assertNotEqual(b.q, a.q)

    def test3(self):
        a = self.any()
        a.q = 'q'
        b = self.uncanny(a)
        del a.q
        try:
            q = b.q
        except AttributeError:
            return True
        raise AttributeError('should not have resolved "q"')


if __name__=="__main__":
    import unittest
    unittest.main()
