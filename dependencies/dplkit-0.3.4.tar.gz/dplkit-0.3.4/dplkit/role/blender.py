#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
package.module
~~~~~~~~~~~~~~


A description which can be long and explain the complete
functionality of this module even with indented code examples.
Class/Function however should not be documented here.


:copyright: 2012 by University of Wisconsin Regents, see AUTHORS for more details
:license: GPLv3, see LICENSE for more details
"""

import os, sys
import logging
from abc import ABCMeta, abstractmethod
from dplkit.role.filter import aFilter
from dplkit.role.decorator import exposes_attrs_of_field

LOG = logging.getLogger(__name__)


@exposes_attrs_of_field('__channel_10')
@exposes_attrs_of_field('__channel_9')
@exposes_attrs_of_field('__channel_8')
@exposes_attrs_of_field('__channel_7')
@exposes_attrs_of_field('__channel_6')
@exposes_attrs_of_field('__channel_5')
@exposes_attrs_of_field('__channel_4')
@exposes_attrs_of_field('__channel_3')
@exposes_attrs_of_field('__channel_2')
@exposes_attrs_of_field('__channel_1')
@exposes_attrs_of_field('__channel_0')
class aBlender(aFilter):
    """
    A blender combines one or more frame streams into a single outgoing stream. Its primary activity is combine()
    """
    __metaclass__ = ABCMeta

    def __init__(self,sources,*args,**kwargs):
        super(aBlender, self).__init__(sources[0])
        for x in range(11):
            setattr(self,'__channel_'+repr(x),None)
        for x in range(1,len(sources)):
            setattr(self,'__channel_'+repr(x-1),sources[x])

    @abstractmethod
    def combine(self, *args, **kwargs):
        """
        """        
        pass

    def process(self, *args, **kwargs):
        return self.combine(*args, **kwargs)



class Merge(aBlender):
    def __init__(self, *sources, **kwargs):
        super(self.__class__, self).__init__(sources)
        self._sources = sources

    def combine(self, *args, **kwargs):
        from ..frame.struct import struct
        for framegroup in zip(self._sources):
            f = struct(framegroup[0])
            for q in framegroup[1:]:
                vars(f).update(vars(q))
            yield f.as_dict()



#
## Code goes here.
#


def test():
    """ """
    pass


if __name__=='__main__':
    test()
