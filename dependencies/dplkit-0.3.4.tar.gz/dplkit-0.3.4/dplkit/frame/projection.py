#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
dplkit.frame.projection
~~~~~~~~~~~~~~~~~~~~~~~

:copyright: 2012 by University of Wisconsin Regents, see AUTHORS for more details
:license: GPLv3, see LICENSE for more details
"""

import os, sys
import logging

LOG = logging.getLogger(__name__)


def test():
    """ """
    pass


if __name__=='__main__':
    test()
