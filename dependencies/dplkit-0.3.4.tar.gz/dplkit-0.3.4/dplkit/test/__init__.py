"""
This module contains common / reusable synthetic test pattern generators.
"""

