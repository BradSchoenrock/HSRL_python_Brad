#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
dplkit.simple.artist
~~~~~~~~~~~~~~~~~~~~

Matplotlib examples from HSRL

:copyright: 2012 by University of Wisconsin Regents, see AUTHORS for more details
:license: GPLv3, see LICENSE for more details
"""

from ..role.artist import aArtist
import os, sys
import logging
from ..role.blender import aBlender

LOG = logging.getLogger(__name__)



class MplMultiLinePlot(aArtist):
    """
    """
    def __init__(self, source, **kwargs):
        super(Merge, self).__init__()
        self._config = kwargs

    def render(self, *args, **kwargs):
        pass







def test():
    """ """
    pass


if __name__=='__main__':
    test()
